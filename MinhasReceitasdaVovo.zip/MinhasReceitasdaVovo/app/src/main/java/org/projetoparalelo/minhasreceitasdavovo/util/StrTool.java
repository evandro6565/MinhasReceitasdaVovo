package org.projetoparalelo.minhasreceitasdavovo.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StrTool {

    public static final int FINAL = 2;
    public static final int TUDO = 1;

    public static String removerEspaco(String str, int opt) {
        if (str == null || str.isEmpty()) {
            return str;
        }

        switch (opt) {
            case TUDO:
                return str.trim();
            case FINAL:
                // Verifica se o último caractere é um espaço
                if (str.charAt(str.length() - 1) == ' ') {
                    return str.substring(0, str.length() - 1); // Remove o último caractere
                }
            default:
                return str;
        }
    }

    public static String formatarIniciaisMaiusculas(String texto) {
        if (texto == null || texto.isEmpty()) {
            return texto;
        }

        // Usa uma expressão regular para capturar palavras e espaços
        Pattern pattern = Pattern.compile("(\\S+)|(\\s+)");
        Matcher matcher = pattern.matcher(texto);

        StringBuilder resultado = new StringBuilder();

        while (matcher.find()) {
            String palavra = matcher.group(1); // Captura palavras
            String espaco = matcher.group(2); // Captura espaços

            if (palavra != null) {
                // Formata a palavra (primeira letra maiúscula, resto minúsculo)
                String palavraFormatada = palavra.substring(0, 1).toUpperCase() +
                        palavra.substring(1).toLowerCase();
                resultado.append(palavraFormatada);
            } else if (espaco != null) {
                // Mantém os espaços originais
                resultado.append(espaco);
            }
        }

        return resultado.toString();
    }
}
