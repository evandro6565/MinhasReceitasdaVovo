package org.projetoparalelo.minhasreceitasdavovo.db.model;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.Serializable;

public class IngredientesModel implements Serializable {
    private Long ID;
    private String nome;
    private String tipo;
    private String quantidade;

    public IngredientesModel(Long ID, String nome, String tipo, String quantidade) {
        defaultConf(ID, nome, tipo, quantidade);
    }

    public IngredientesModel(String nome, String tipo, String quantidade) {
        defaultConf(null, nome, tipo, quantidade);
    }

    public IngredientesModel(@NonNull IngredientesModel ref) {
        defaultConf(ref.getID(), ref.getNome(), ref.getTipo(), ref.getQuantidade());
    }

    public IngredientesModel() {}

    private void defaultConf(Long ID, String nome, String tipo, String quantidade) {
        this.ID = ID;
        this.nome = nome;
        this.tipo = tipo;
        this.quantidade = quantidade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * retorna -1 se ID estiver null
     * @return String
     */
    public String getParseID() {
        if (ID == null) return "-1";
        return String.valueOf(ID);
    }
    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }

    @Override
    public String toString() {
        return nome;
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        if (this == obj) return true; // se for o mesmo objeto instanciado na memoria
        if (!(obj instanceof IngredientesModel)) return false;
        return this.ID == ((IngredientesModel) obj).getID();
    }

    @Override
    public int hashCode() {
        return ID != null? Long.hashCode(ID) : 0;
    }
}
