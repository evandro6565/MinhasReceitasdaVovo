package org.projetoparalelo.minhasreceitasdavovo.util;

import org.projetoparalelo.minhasreceitasdavovo.R;

public class MenuHelp {
    public static final int DisableFavoritos = R.id.btnFavoritos;
    public static final int DisableHome = R.id.btnInicio;
    public static final int DisablePerfil = R.id.btnPerfil;

    public static int IC_HOME = 23, IC_PERFIL = 12, IC_PERFIL_EDITAR = 14, IC_FAVORITO = 45;
}
