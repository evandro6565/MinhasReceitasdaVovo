package org.projetoparalelo.minhasreceitasdavovo.db;

import android.database.Cursor;

import org.jetbrains.annotations.NotNull;

public class CursoX {
    public static final boolean CLOSE_CURSOR = true;
    private Cursor cursor;

    public void setCursor(Cursor cursor) {
        this.cursor = cursor;
    }

    public void closeCursor() {
        this.cursor.close();
    }

    public boolean cursorNext() {
        return this.cursor.moveToNext();
    }

    public int cursorCount() {
        return cursor.getCount();
    }

    public boolean cursorHasData(boolean close) {
        boolean result = cursor.getCount() > 0;
        if (close) cursor.close();
        return result;
    }
    public boolean cursorHasData() {
        return cursorHasData(false);
    }

    public static long getLong(@NotNull Cursor seta, String column) {
        return seta.getLong(seta.getColumnIndexOrThrow(column));
    }
    public long getCursorLong(String column) {
        return cursor.getLong(cursor.getColumnIndexOrThrow(column));
    }

    public static int getInt(@NotNull Cursor seta, String column) {
        return seta.getInt(seta.getColumnIndexOrThrow(column));
    }
    public int getCursorInt(String column) {
        return cursor.getInt(cursor.getColumnIndexOrThrow(column));
    }

    public static String getString(@NotNull Cursor seta, String column) {
        return seta.getString(seta.getColumnIndexOrThrow(column));
    }
    public String getCursorString(String column) {
        return cursor.getString(cursor.getColumnIndexOrThrow(column));
    }

}
