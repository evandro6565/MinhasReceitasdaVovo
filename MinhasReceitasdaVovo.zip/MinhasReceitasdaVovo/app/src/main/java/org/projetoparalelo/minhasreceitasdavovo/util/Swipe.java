package org.projetoparalelo.minhasreceitasdavovo.util;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.Toast;

import org.projetoparalelo.minhasreceitasdavovo.R;

public class Swipe {
    public static final int DISABLE = -1;
    public static final int OnlyFinishLeft = 34;
    public static final int OnlyFinishRight = 23;
    public static final int OnlyFinishAll = 12;

    public Swipe(Activity activity, View rootView, Class<?> targedLeft, Class<?> targedRight, int OnlyFinish) {
        init(activity, rootView, targedLeft, targedRight, OnlyFinish);
    }

    public Swipe(Activity activity, View rootView, Class<?> targedLeft, Class<?> targedRight) {
        init(activity, rootView, targedLeft, targedRight, DISABLE);
    }

    private void init(Activity activity, View rootView, Class<?> targedLeft, Class<?> targedRight, int OnlyFinish) {

        //View rootView = activity.findViewById(R.id.scrollview); // ou qualquer view que você quiser escutar
        rootView.setOnClickListener(v -> {});
        rootView.setOnTouchListener(new OnSwipeTouchListener(activity, new OnSwipeListener() {
            @Override
            public void onSwipeRight() {
                Toast.makeText(activity, "Swiped para a direita", Toast.LENGTH_SHORT).show();
                if (targedRight != null) {

                    if (! ((OnlyFinish == OnlyFinishAll) || (OnlyFinish == OnlyFinishRight)))
                        activity.startActivity(new Intent(activity, targedRight)
                            .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));

                    //activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                    activity.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                    activity.finish();
                }
            }

            @Override
            public void onSwipeLeft() {
                Toast.makeText(activity, "Swiped para a esquerda", Toast.LENGTH_SHORT).show();
                if (targedLeft != null) {
                    if (! ((OnlyFinish == OnlyFinishAll) || (OnlyFinish == OnlyFinishLeft)))
                        activity.startActivity(new Intent(activity, targedLeft)
                                .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));

                    //activity.overridePendingTransition(R.anim.slide_out_right, R.anim.slide_in_left);
                    activity.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                    activity.finish();
                }
            }
        }));
    }

}
