package org.projetoparalelo.minhasreceitasdavovo;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import org.projetoparalelo.minhasreceitasdavovo.db.DatabaseHelpe;
import org.projetoparalelo.minhasreceitasdavovo.db.model.IngredientesModel;
import org.projetoparalelo.minhasreceitasdavovo.db.model.ReceitaModel;
import org.projetoparalelo.minhasreceitasdavovo.db.model.UserModel;
import org.projetoparalelo.minhasreceitasdavovo.util.FixLayout;
import org.projetoparalelo.minhasreceitasdavovo.util.SessionManager;
import org.projetoparalelo.minhasreceitasdavovo.util.Swipe;

import java.util.List;

public class ReceitaDetalheActivity extends AppCompatActivity {

    private DatabaseHelpe database;
    private SessionManager sessionManager;
    private boolean addButoes;
    private ReceitaModel receita;
    private String de_onde_veio;

    private Button btnExcluir, btnEditar;
    private CheckBox checkboxFavorito;
    private TextView login_regis, sigla_perfil;

    private ActivityResultLauncher<Intent> activityResultLauncher;

    private String tag = "ReceitaDetalhe_debug";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receita_detalhe);
        getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        if (!receberReceita()) {
            finish();
            return;
        }

        sessionManager = new SessionManager(this);
        database = new DatabaseHelpe(this, sessionManager.getUser());

        login_regis = findViewById(R.id.login_regis);
        sigla_perfil = findViewById(R.id.sigla_perfil);

        TextView textViewTitulo = findViewById(R.id.textViewTitulo);
        TextView textViewTempoPreparo = findViewById(R.id.textViewTempoPreparo);
        TextView textViewDescricao = findViewById(R.id.textViewDescricao);
        TextView textViewNomeUser = findViewById(R.id.textViewNomeUser);
        TextView textViewVoltar = findViewById(R.id.textViewVoltar);

        textViewTitulo.setText(receita.getTitulo());
        textViewTempoPreparo.setText(receita.getTempo_preparo());
        textViewNomeUser.setText(receita.getUser().getNome());
        textViewDescricao.setText(receita.getDescricao());

        textViewVoltar.setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });

        checkboxFavorito = findViewById(R.id.checkboxFavorito);
        btnEditar = findViewById(R.id.btnEditar);
        btnExcluir = findViewById(R.id.btnExcluir);

        View rootView = findViewById(R.id.scrollview);
        new Swipe(this, rootView, null, getCallBack());
        View layoutContentLeft = findViewById(R.id.layoutContentLeft);
        new Swipe(this, layoutContentLeft, null, getCallBack());

        preencherIngredientes();
        permiss();
        ajustarLayout();
        FixLayout.ajustarLayoutBarrasSwipe(this);

        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        receita = (ReceitaModel) result.getData().getSerializableExtra("receita_atualizada");
                        if (receita != null) {
                            // Atualize seu RecyclerView ou lista aqui
                            Log.d(tag, "Receita atualizada: " + receita.getTitulo());

                            textViewTitulo.setText(receita.getTitulo());
                            textViewTempoPreparo.setText(receita.getTempo_preparo());
                            textViewNomeUser.setText(receita.getUser().getNome());
                            textViewDescricao.setText(receita.getDescricao());

                            preencherIngredientes();
                        }
                    }
                }
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        ajustarLayout();
        preencherIngredientes();
    }

    private Class<?> getCallBack() {
        if (de_onde_veio == null) return null;

        if (de_onde_veio.equals(PerfilActivity.class.getSimpleName()))
            return PerfilActivity.class;
        if (de_onde_veio.equals(PerfilFavoritosActivity.class.getSimpleName()))
            return PerfilFavoritosActivity.class;
        if (de_onde_veio.equals(MainActivity.class.getSimpleName()))
            return MainActivity.class;

        return null;
    }

    private boolean receberReceita() {
        if (getIntent().hasExtra("receita_object")) {
            receita = (ReceitaModel) getIntent().getSerializableExtra("receita_object");
            de_onde_veio = getIntent().getStringExtra("de_onde_veio");
            // Use a receita aqui
            return true;
        }
        Log.e(tag, "Erro no method receberReceita, receita não recebida");
        return false;
    }

    private void ajustarLayout() {
        ImageView imageBackground = findViewById(R.id.imageBackground);
        LinearLayout containerLayout = findViewById(R.id.containerLayout);

        // Espera até o layout ser desenhado para pegar a altura real
        containerLayout.post(() -> {
            int altura = containerLayout.getHeight();

            // Atualiza a altura da imagem de fundo para ser igual à do conteúdo
            ViewGroup.LayoutParams params = imageBackground.getLayoutParams();
            params.height = altura;
            imageBackground.setLayoutParams(params);
        });
    }

    private void preencherIngredientes() {
        TextView txtIngredientes = findViewById(R.id.textViewIngredientes);
        String base = "<font color='#e91e63'>●</font>INFO<br>";
        List<IngredientesModel> ingredientes = receita.getIngredientes();

        String html = "";
        if (ingredientes.size() <= 0) html = "NaN";
//                "<font color='#e91e63'>●</font>2 ovos<br>" +
//                "<font color='#e91e63'>●</font> 1 xícara de leite<br>" +
//                "<font color='#e91e63'>●</font> 3 colheres de farinha<br>" +
//                "<font color='#e91e63'>●</font> Sal a gosto";

        for (IngredientesModel ing : ingredientes) {
            html += base.replace("INFO",ing.getQuantidade()+" "+ing.getNome());
        }

        txtIngredientes.setText(Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY));
    }

    private void permiss() {
        if (!sessionManager.isLoggedIn()) {
            checkboxFavorito.setVisibility(View.GONE);
            btnEditar.setVisibility(View.GONE);
            btnExcluir.setVisibility(View.GONE);
            sigla_perfil.setVisibility(View.GONE);
            login_regis.setVisibility(View.VISIBLE);
            login_regis.setOnClickListener(v -> {
                startActivity(new Intent(this, CadastrarContaActivity.class));
                finish();
            });
            return;
        }
        login_regis.setVisibility(View.GONE);
        sigla_perfil.setVisibility(View.VISIBLE);
        sigla_perfil.setText(sessionManager.getUser().getSiglaNome());
        database = new DatabaseHelpe(this, sessionManager.getUser());




        if (!receita.getUser().itsMe(sessionManager.getUser())) {
            btnEditar.setVisibility(View.GONE);
            btnExcluir.setVisibility(View.GONE);
        }
        // Alert customizado
        LayoutInflater inflater = LayoutInflater.from(this);
        View customView = inflater.inflate(R.layout.dialog_custom_layout, null);
        AlertDialog alertDialog = new AlertDialog.Builder(this, R.style.MyAlertDialogStyle)
                .setView(customView)
                .create();

        ((TextView) customView.findViewById(R.id.dialog_message))
                .setText("Tem certeza de que deseja excluir sua receita");

        if (!addButoes) {
            addButoes = true;

            checkboxFavorito.setVisibility(View.VISIBLE);

            if (receita.getUser().itsMe(sessionManager.getUser())) {
                btnEditar.setVisibility(View.VISIBLE);
                btnExcluir.setVisibility(View.VISIBLE);

                btnEditar.setOnClickListener(v -> {
                    activityResultLauncher.launch(new Intent(this, EditarReceitaActivity.class)
                            .putExtra("recipe_object", receita));
                });

                btnExcluir.setOnClickListener(v -> {
                    alertDialog.show();

                    ((Button) customView.findViewById(R.id.btn_cancelar)).setOnClickListener(v_btn_cancelar -> {
                        alertDialog.dismiss();
                    });

                    ((Button) customView.findViewById(R.id.btn_confirmar)).setOnClickListener(v_btn_confirmar -> {
                        alertDialog.dismiss();
                        if (database.Model().getReceitas().delete(receita)) {
                            startActivity(new Intent(this, getCallBack()));
                            finish();
                        }
                    });
                });
            }

            checkboxFavorito.setChecked(receita.isFavorite());
            checkboxFavorito.setOnCheckedChangeListener(((buttonView, isChecked) -> {
                UserModel user = sessionManager.getUser();
                if (isChecked)
                    database.Model().getReceitas().setMarkFavorito(user, receita);
                else
                    database.Model().getReceitas().setDisMarkFavorito(user, receita);

            }));
        }
    }

}