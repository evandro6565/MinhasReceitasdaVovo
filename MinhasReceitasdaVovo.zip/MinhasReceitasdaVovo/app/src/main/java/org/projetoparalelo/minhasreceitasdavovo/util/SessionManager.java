package org.projetoparalelo.minhasreceitasdavovo.util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatDelegate;

import org.projetoparalelo.minhasreceitasdavovo.MainActivity;
import org.projetoparalelo.minhasreceitasdavovo.db.model.UserModel;

public class SessionManager {
    private static final String PREF_NAME = "user_session";
    private SharedPreferences prefs;
    private boolean staylogged, savepass, isLoggedIn;
    private Context context;

    private String pass;

    public SessionManager(@NonNull Context context) {
        this.context = context;
        prefs = this.context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        staylogged = prefs.getBoolean("stay_logged", false); // permanecer logado
        isLoggedIn = prefs.getBoolean("isLoggedIn", false); // se esta logado

        pass = prefs.getString("user_pass", null);
        savepass = pass != null; // salvar senha
    }

    public void saveUser(@NonNull UserModel user) {
        if (user.getID() == null)
            throw new NullPointerException("Erro em sessionManager.saveUser: identificador do usuario está nulo");
        SharedPreferences.Editor editor = prefs.edit();
        editor.putLong("user_id", user.getID());
        editor.putString("user_nome", user.getNome());
        editor.putString("user_email", user.getEmail());
        editor.putString("user_pass", savepass? user.getSenha() : null);
        editor.putBoolean("stay_logged", staylogged);
        editor.putBoolean("isLoggedIn", isLoggedIn);
        editor.apply();
    }

    public void stayLogged(boolean allow) {
        staylogged = allow;
    }

    public void savePass(boolean allow) {
        savepass = allow;
    }

    public void loginSucess() {
        isLoggedIn = true;
    }

    public UserModel getUser() {
        long id = prefs.getLong("user_id", -1);
        String nome = prefs.getString("user_nome", null);
        String email = prefs.getString("user_email", null);
        String pass = prefs.getString("user_pass", null);
        return new UserModel(id == -1? null:id, email, nome, pass);
    }

    public boolean isLoggedIn() {
        return prefs.getBoolean("isLoggedIn", false);
    }

    public void logout() {
        String pass = prefs.getString("user_pass", null);
        if (!staylogged && !savepass)
            prefs.edit().clear().apply();

        if (!staylogged)
            prefs.edit().putBoolean("isLoggedIn", false).apply();

        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        context.startActivity(intent);
        if (context instanceof Activity)
            ((Activity) (context)).finish();
    }

    public void limparSessao_e_logout() {
        logout();
        prefs.edit().clear().apply();
    }

    public long getUserID() {
        return prefs.getLong("user_id", -1);
    }

}
