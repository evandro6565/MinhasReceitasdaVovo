package org.projetoparalelo.minhasreceitasdavovo.db.model;

public class ReceitaIngredientesModel {
    private Long ID, receita_ID, ingrediente_ID;
    private String quantidade;

    public ReceitaIngredientesModel(Long ID, Long receita_ID, Long ingrediente_ID, String quantidade) {
        this.ID = ID;
        this.receita_ID = receita_ID;
        this.ingrediente_ID = ingrediente_ID;
        this.quantidade = quantidade;
    }

    public ReceitaIngredientesModel() {}

    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }

    public Long getReceita_ID() {
        return receita_ID;
    }

    public void setReceita_ID(Long receita_ID) {
        this.receita_ID = receita_ID;
    }

    public Long getIngrediente_ID() {
        return ingrediente_ID;
    }

    public void setIngrediente_ID(Long ingrediente_ID) {
        this.ingrediente_ID = ingrediente_ID;
    }

    public String getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }
}
