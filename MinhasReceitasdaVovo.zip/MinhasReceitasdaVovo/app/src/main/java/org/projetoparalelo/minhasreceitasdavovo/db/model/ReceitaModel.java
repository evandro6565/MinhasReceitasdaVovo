package org.projetoparalelo.minhasreceitasdavovo.db.model;

import org.projetoparalelo.minhasreceitasdavovo.db.DatabaseHelpe;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ReceitaModel implements Serializable {
    private Long ID;
    private String Titulo;
    private String Descricao;
    private String Tempo_preparo;

    private UserModel user;
    private CategoriaModel categoria;
    private List<IngredientesModel> ingredientes;

    private boolean markFavorite;

    public ReceitaModel(Long ID, String titulo, String descricao, String tempo_preparo, CategoriaModel categoriaModel, UserModel userModel, List<IngredientesModel> ingredientes) {
        defaultConf(ID, titulo, descricao, tempo_preparo, categoriaModel, userModel, ingredientes);
    }

    public ReceitaModel(Long ID, String titulo, String descricao, String tempo_preparo, CategoriaModel categoriaModel, UserModel userModel) {
        defaultConf(ID, titulo, descricao, tempo_preparo, categoriaModel, userModel, null);
    }

    public ReceitaModel(String titulo, String descricao, String tempo_preparo, CategoriaModel categoriaModel, UserModel userModel) {
        defaultConf(null, titulo, descricao, tempo_preparo, categoriaModel, userModel, null);
    }

    public ReceitaModel(ReceitaModel ref) {
        defaultConf(ref.getID(), ref.getTitulo(), ref.getDescricao(), ref.getTempo_preparo(), ref.getCategoria(), ref.getUser(), ref.getIngredientes());
    }

    public ReceitaModel() {}

    private void defaultConf(Long ID, String titulo, String descricao, String tempo_preparo, CategoriaModel categoriaModel, UserModel userModel, List<IngredientesModel> ingredientesList) {
        this.ID = ID;
        Titulo = titulo;
        Descricao = descricao;
        Tempo_preparo = tempo_preparo;
        categoria = categoriaModel;
        user = userModel;
        markFavorite = false;
        this.ingredientes = ingredientesList;
    }

    public boolean itsMe(UserModel user) {
        if (getID() == user.getID())
            return true;
        return false;
    }

    public boolean isFavorite() {
        return markFavorite;
    }

    public void setMarkFavorite(boolean markFavorite) {
        this.markFavorite = markFavorite;
    }

    public List<IngredientesModel> getIngredientes() {
        if (ingredientes == null) ingredientes = new ArrayList<>();
        return ingredientes;
    }

    public void setIngredientes(List<IngredientesModel> ingredientes) {
        this.ingredientes = ingredientes;
    }

    public UserModel getUser() {
        if (user == null) user = new UserModel();
        return user;
    }

    public void setUser(UserModel user) {
        this.user = new UserModel(user);
    }

    public CategoriaModel getCategoria() {
        return categoria;
    }

    public void setCategoria(CategoriaModel categoria) {
        this.categoria = categoria;
    }

    /**
     * retorna -1 se ID estiver null
     * @return String
     */
    public String getParseID() {
        if (ID == null) return "-1";
        return String.valueOf(ID);
    }
    public Long getID() {
        return ID;
    }

    public ReceitaModel setID(Long ID) {
        this.ID = ID;
        return this;
    }

    public String getTitulo() {
        return Titulo;
    }

    public void setTitulo(String titulo) {
        Titulo = titulo;
    }

    public String getDescricao() {
        return Descricao;
    }

    public void setDescricao(String descricao) {
        Descricao = descricao;
    }

    public String getTempo_preparo() {
        return Tempo_preparo;
    }

    public void setTempo_preparo(String tempo_preparo) {
        Tempo_preparo = tempo_preparo;
    }
}
