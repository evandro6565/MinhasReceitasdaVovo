package org.projetoparalelo.minhasreceitasdavovo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.projetoparalelo.minhasreceitasdavovo.db.DatabaseHelpe;
import org.projetoparalelo.minhasreceitasdavovo.db.model.ReceitaModel;
import org.projetoparalelo.minhasreceitasdavovo.db.model.UserModel;
import org.projetoparalelo.minhasreceitasdavovo.util.FixLayout;
import org.projetoparalelo.minhasreceitasdavovo.util.MenuHelp;
import org.projetoparalelo.minhasreceitasdavovo.util.MenuBarInferior;
import org.projetoparalelo.minhasreceitasdavovo.util.SessionManager;
import org.projetoparalelo.minhasreceitasdavovo.util.Swipe;

public class PerfilActivity extends AppCompatActivity {

    private SessionManager sessionManager;
    private RecipeAdapter recipeAdapter;
    private DatabaseHelpe database;
    private UserModel user;
    private MenuBarInferior menuInferior;

    private TextView nome_perfil, email_perfil, sigla_perfil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);
        getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        sessionManager = new SessionManager(this);
        if (!sessionManager.isLoggedIn()) {
            finish();
            return;
        }

        menuInferior = new MenuBarInferior(this);

        user = sessionManager.getUser();
        database = new DatabaseHelpe(this, user);

        nome_perfil = findViewById(R.id.nome_perfil);
        sigla_perfil = findViewById(R.id.sigla_perfil);
        email_perfil = findViewById(R.id.email_perfil);

        nome_perfil.setText(user.getNome());
        email_perfil.setText(user.getEmail());
        sigla_perfil.setText(user.getSiglaNome());

        Button btnLogout = findViewById(R.id.btnLogout);
        btnLogout.setOnClickListener(v -> {
            sessionManager.logout();
        });

        Button btnEditarPerfil = findViewById(R.id.btnEditarPerfil);
        btnEditarPerfil.setOnClickListener(v -> {
            Intent intent = new Intent(this, PerfilEditarActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
        });

        Button btnNovaReceita = findViewById(R.id.btnNovaReceita);
        btnNovaReceita.setOnClickListener(v -> {
            Intent intent = new Intent(this, CadastrarReceitaActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
        });

        RecyclerView recyclerViewRecipes = findViewById(R.id.recyclerViewRecipes);
        recyclerViewRecipes.setLayoutManager(new LinearLayoutManager(this));

        recipeAdapter = new RecipeAdapter(this, database.Model().getReceitas().getRecipesByUser(user),
                new RecipeAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(ReceitaModel receita) {
                        // Abrir detalhes da receita
                        Intent intent = new Intent(PerfilActivity.this, ReceitaDetalheActivity.class);
                        intent.putExtra("receita_object", receita);
                        intent.putExtra("de_onde_veio", PerfilActivity.class.getSimpleName());
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        startActivity(intent);
                    }

                    @Override
                    public void onCheckChanged(ReceitaModel receita, boolean isChecked) {
                        if (isChecked)
                            database.Model().getReceitas().setMarkFavorito(receita);
                        else
                            database.Model().getReceitas().setDisMarkFavorito(receita);
                    }
                });
        recyclerViewRecipes.setAdapter(recipeAdapter);

        View rootView = findViewById(R.id.scrollview);
        new Swipe(this, rootView, PerfilEditarActivity.class, PerfilFavoritosActivity.class);
        View layoutContentRightView = findViewById(R.id.layoutContentRight);
        new Swipe(this, layoutContentRightView, PerfilEditarActivity.class, null);
        View layoutContentLeft = findViewById(R.id.layoutContentLeft);
        new Swipe(this, layoutContentLeft, null, PerfilFavoritosActivity.class);

        menuInferior.make(MenuHelp.DisablePerfil);
        menuInferior.markMenuIcon(MenuHelp.IC_PERFIL);
        FixLayout.ajustarLayoutBarrasSwipe(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (user == null || user.getID() == null) return;
        recipeAdapter.atualizadarLista(database.Model().getReceitas().getRecipesByUser(user));
    }
}