package org.projetoparalelo.minhasreceitasdavovo;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;

import org.projetoparalelo.minhasreceitasdavovo.db.DatabaseHelpe;
import org.projetoparalelo.minhasreceitasdavovo.db.model.DatabaseModel;
import org.projetoparalelo.minhasreceitasdavovo.db.model.UserModel;
import org.projetoparalelo.minhasreceitasdavovo.util.EditTextM;
import org.projetoparalelo.minhasreceitasdavovo.util.SessionManager;

public class CadastrarContaActivity extends AppCompatActivity {

    private LinearLayout layoutSucesso, layoutFormulario;
    private DatabaseHelpe database;
    private TextView txtMsgErr;

    private EditTextM edtNameUser;
    private EditTextM edtEmail;
    private EditTextM edtSenha;
    private EditTextM edtConfirmarSenha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar_conta);

        SessionManager sessionManager = new SessionManager(this);
        if (sessionManager.isLoggedIn()) {
            finish();
            return;
        }

        database = new DatabaseHelpe(this);

        layoutSucesso = findViewById(R.id.sucesso);
        layoutFormulario = findViewById(R.id.formulario);

        layoutSucesso.setVisibility(View.GONE);
        layoutFormulario.setVisibility(View.VISIBLE);

        txtMsgErr = findViewById(R.id.txtMsgErr);
        txtMsgErr.setVisibility(View.INVISIBLE);

        edtNameUser = findViewById(R.id.edtNameUser);
        edtEmail = findViewById(R.id.edtEmail);
        edtSenha = findViewById(R.id.edtSenha);
        edtConfirmarSenha = findViewById(R.id.edtConfirmarSenha);
        detectarMinSenha(edtSenha);
        detectarMinSenha(edtConfirmarSenha);
        detectarEmailInvalido(edtEmail);

        edtNameUser.formatarNomes();
        edtEmail.enableEmail(database);
        edtSenha.enablePass(this);
        edtConfirmarSenha.enablePass(this);
        edtSenha.setLimiteMinimoDaSenha(6);
        edtConfirmarSenha.setLimiteMinimoDaSenha(6);
        edtConfirmarSenha.enableConfirmPass(this, edtSenha);

        Button btnCadastrar = findViewById(R.id.btnCadastrar);
        btnCadastrar.setOnClickListener(v -> {
            if (checkCampos()) {
                UserModel user = new UserModel();
                user.setNome(getStr(edtNameUser));
                user.setEmail(getStr(edtEmail));
                user.setSenha(getStr(edtSenha));

                if (!database.Model().getUser().validar(user, DatabaseModel.User.VALIDAR_IF_EXIST)) {
                    txtMsgErr.setVisibility(View.INVISIBLE);
                    database.Model().getUser().insertOrUpdate(user);
                    showSucessCreat();
                } else {
                    txtMsgErr.setVisibility(View.VISIBLE);
                    txtMsgErr.setText("Essa conta já exite");
                }
            }
        });

        ((TextView) findViewById(R.id.txtLogin)).setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class)
                    .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
        });

    }

    private boolean checkCampos() {
        String msg = getStr(edtConfirmarSenha).isBlank()? "Confirme a sua senha":"Há Campos Faltando.";

        if (_isBlank(edtSenha, msg) ||
                _isBlank(edtConfirmarSenha, msg) ||
                _isBlank(edtNameUser, msg) ||
                _isBlank(edtEmail, msg)
        ) {
            txtMsgErr.setVisibility(View.VISIBLE);
            txtMsgErr.setText(msg);
            return false;
        }

        if (!edtSenha.validatePass(true) || !edtConfirmarSenha.validatePass(true)) {
            txtMsgErr.setVisibility(View.VISIBLE);
            txtMsgErr.setText("As senhas tem que ter no minimo 6 caracteres.");
            return false;
        }

        if (!getStr(edtSenha).equals(getStr(edtConfirmarSenha))) {
            txtMsgErr.setVisibility(View.VISIBLE);
            txtMsgErr.setText("As senhas não são iguais.");
            if (edtConfirmarSenha.isFocusable()) {
                edtConfirmarSenha.setError("As senhas não são iguais.");
            }
            return false;
        }

        if (!edtEmail.validateEmail()) {
            txtMsgErr.setVisibility(View.VISIBLE);
            txtMsgErr.setText("Formato de email invalido");
            return false;
        }

        txtMsgErr.setVisibility(View.INVISIBLE);
        return true;
    }

    private boolean _isBlank(EditTextM ed, String msg) {
        boolean isb = getStr(ed).isBlank();
        if (isb) {
            ed.setError(msg);
            ed.requestFocus();
        }
        return isb;
    }

    private String getStr(EditTextM ed) {
        return ed.getText().toString();
    }

    private void carregarGif() {
        ImageView gifImageView = findViewById(R.id.gifImageView);
        Glide.with(this)
                .asGif()
                .load(R.drawable.loading_slow) // pode ser local ou URL
                .into(gifImageView);
    }

    private void showSucessCreat() {
        layoutFormulario.setVisibility(View.GONE);
        layoutSucesso.setVisibility(View.VISIBLE);

        Button btnIrLogin = findViewById(R.id.btnIrLogin);
        btnIrLogin.setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
        });

        carregarGif();
    }

    private void detectarMinSenha(EditTextM edSenha) {
        edSenha.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (before > 0 || count > 0) {
                    // Inserção ou remoção detectada
                    //Log.d("EditText", "Inserido: " + s.subSequence(start, start + count));
                    if (edSenha.getId() == R.id.edtSenha)
                        if (!edSenha.validatePass(true)) {
                            txtMsgErr.setVisibility(View.VISIBLE);
                            txtMsgErr.setText("As senhas tem que ter no minimo 6 caracteres.");
                        } else
                            txtMsgErr.setVisibility(View.INVISIBLE);
                    else {
                        if (!getStr(edSenha).equals(getStr(edtSenha))) {
                            txtMsgErr.setVisibility(View.VISIBLE);
                            txtMsgErr.setText("As senhas não são iguais");
                        } else if (!edSenha.validatePass(true)) {
                            txtMsgErr.setVisibility(View.VISIBLE);
                            txtMsgErr.setText("As senhas tem que ter no minimo 6 caracteres.");
                        } else
                            txtMsgErr.setVisibility(View.INVISIBLE);
                    }
                }
            }

            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });
    }
    private void detectarEmailInvalido(EditTextM edEmail) {
        edEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (before > 0 || count > 0) {
                    // Inserção ou remoção detectada
                    //Log.d("EditText", "Inserido: " + s.subSequence(start, start + count));
                    if (!edEmail.validateEmail()) {
                        txtMsgErr.setVisibility(View.VISIBLE);
                        txtMsgErr.setText("Formato de email invalido");
                    } else
                        txtMsgErr.setVisibility(View.INVISIBLE);
                }
            }

            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });
    }
}