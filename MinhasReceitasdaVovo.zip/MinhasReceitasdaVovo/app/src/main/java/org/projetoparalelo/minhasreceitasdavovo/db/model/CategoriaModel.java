package org.projetoparalelo.minhasreceitasdavovo.db.model;

import androidx.annotation.NonNull;

import java.io.Serializable;
import java.util.Objects;

public class CategoriaModel implements Serializable {
    private String nome;

    public CategoriaModel(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @NonNull
    @Override
    public String toString() {
        return nome.isBlank()? "Null" : nome;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof CategoriaModel)) return false;
        CategoriaModel categoria = (CategoriaModel) obj;
        return nome != null && nome.equals(categoria.getNome());
    }

    @Override
    public int hashCode() {
        return nome != null? nome.hashCode() : 0;
    }
}
