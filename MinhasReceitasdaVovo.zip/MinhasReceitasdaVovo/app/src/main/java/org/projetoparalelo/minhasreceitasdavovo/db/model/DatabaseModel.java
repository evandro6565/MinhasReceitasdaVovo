package org.projetoparalelo.minhasreceitasdavovo.db.model;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

public class DatabaseModel {
    private static SQLiteOpenHelper database;
    private static UserModel user;
    private static Context context;

    public DatabaseModel(SQLiteOpenHelper database) {
        DatabaseModel.database = database;
    }

    public DatabaseModel(SQLiteOpenHelper database, UserModel user) {
        DatabaseModel.database = database;
        DatabaseModel.user = user;
    }

    public DatabaseModel(Context context, SQLiteOpenHelper database, UserModel user) {
        DatabaseModel.database = database;
        DatabaseModel.user = user;
        DatabaseModel.context = context;
    }

    public static class User extends Model {

        public static final String Tabela = "user";
        public static final String ID = "id";
        public static final String Nome = "nome";
        public static final String Email = "email";
        public static final String Senha = "senha";

        private static final String CT = "CREATE TABLE "+Tabela+" ("+
                ID+" INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Nome + " TEXT, " +
                Email + " TEXT UNIQUE, "+
                Senha + " TEXT)";

        public User(SQLiteDatabase db) {
            super(CT, db);
        }
        public User() {super();}

        public long insertOrUpdate(UserModel user) {
            try {
                SQLiteDatabase db = DatabaseModel.database.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put(Nome, user.getNome());
                values.put(Email, user.getEmail());
                values.put(Senha, user.getMD5Senha());

                // Tentativa de atualização
                int rows = db.update(Tabela, values,
                        ID + " = ?",
                        new String[]{user.getParseID()});

                // Se não atualizou nada, insere
                if (rows <= 0) {
                    return db.insertOrThrow(Tabela, null, values);
                } else {
                    return rows;
                }
            } catch (Exception e) {
                Log.e("DatabaseModel", "erro em insertOrUpdate na class User, erro: "+e.getMessage());
            }
            return -1;
        }

        public UserModel getUserByID(Long id) {
            if (id == null) return null;
            try {
                SQLiteDatabase db = DatabaseModel.database.getReadableDatabase();
                setCursor(db.rawQuery("SELECT * FROM " + Tabela + " WHERE " + ID + " = ?", new String[]{String.valueOf(id)}));

                UserModel user = null;
                if (cursorNext()) {
                    user = new UserModel(getCursorLong(ID), getCursorString(Email), getCursorString(Nome), getCursorString(Senha));
                }
                closeCursor();
                db.close();
                return user;
            } catch (Exception e) {
                Log.e("DatabaseModel", "erro em getUserByID na class User, erro: "+e.getMessage());
                return null;
            }
        }

        public static final boolean VALIDAR_LOGIN = true, VALIDAR_IF_EXIST = false;
        public boolean validar(UserModel user, boolean type) {
            if (user == null) return false;
            String sql;
            String[] args;
            try {
                SQLiteDatabase db = DatabaseModel.database.getReadableDatabase();

                if (type) {
                    sql = "SELECT * FROM " + Tabela + " WHERE " + Email + " = ? and " + Senha + " = ?";
                    args = new String[]{user.getEmail(), user.getMD5Senha()};
                } else {
                    if (user.getEmail() == null || user.getEmail().isBlank()) return false;
                    sql = "SELECT * FROM " + Tabela + " WHERE " + Email + " = ?";
                    args = new String[]{user.getEmail()};
                }
                Cursor cursor = db.rawQuery(sql, args);
                setCursor(cursor);

                if (cursorNext()) {
                    user.setID(getCursorLong(ID));
                    user.setNome(getCursorString(Nome));
                    user.setEmail(getCursorString(Email));
                    user.setSenha(getCursorString(Senha));
                }
                setCursor(cursor);
                db.close();
                return cursorHasData(CLOSE_CURSOR);
            } catch (Exception e) {
                Log.e("DatabaseModel", "erro na função validar class User, error: "+e.getMessage());
            }
            return false;
        }

        public long deletar(@NonNull UserModel user) {
            if (getUserByID(user.getID()) == null) {
                Log.e("DatabaseModel", "Usuário não encontrado para exclusão.");
                return -1;
            }

            try {
                SQLiteDatabase db = DatabaseModel.database.getWritableDatabase();
                db = DatabaseModel.database.getWritableDatabase();
                int rowsDeleted = db.delete(User.Tabela, User.ID + " = ?", new String[]{user.getParseID()});
                db.close();
                return rowsDeleted;

            } catch (Exception e) {
                Log.e("DatabaseModel", "erro em deletar na class User, erro: "+e.getMessage());
            }
            return -1;
        }
    }
    public User getUser(SQLiteDatabase db) {
        return new User(db);
    }
    public User getUser() {
        return new User();
    }

    public static class Receitas extends Model {

        public static final String Tabela = "receita";
        public static final String ID = "id";
        public static final String Titulo = "titulo";
        public static final String Descricao = "descricao";
        public static final String Tempo_preparo = "tempo_preparo";
        public static final String Categoria = "categoria";
        public static final String User_ID = "user_id";

        public static String TID() {
            return Tabela+"."+ID;
        }
        public static String TTitulo() {
            return Tabela+"."+Titulo;
        }
        public static String TDescricao() {
            return Tabela+"."+Descricao;
        }
        public static String TTempo_preparo() {
            return Tabela+"."+Tempo_preparo;
        }
        public static String TCategoria() {
            return Tabela+"."+Categoria;
        }
        public static String TUser_ID() {
            return Tabela+"."+User_ID;
        }
        public static String TALL() {
            String p = ", ";
            return TID()+p+TTitulo()+p+TDescricao()+p+TTempo_preparo()+p+TCategoria()+p+TUser_ID();
        }

        private static final String CT = "CREATE TABLE "+Tabela+" (" +
                ID+" INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Titulo+" TEXT, " +
                Descricao + " TEXT, " +
                Tempo_preparo + " TEXT, " +
                Categoria + " TEXT, " +
                User_ID + " INTEGER, " +
                "FOREIGN KEY("+User_ID+") REFERENCES "+User.Tabela+"("+User.ID+") ON DELETE CASCADE)";

        public Receitas(SQLiteDatabase db) {
            super(CT, db);
        }
        public Receitas() {
            super();
            //del();
        }

        public void del() {
            try {
                SQLiteDatabase db = DatabaseModel.database.getWritableDatabase();
                db.delete(Tabela, null, null);
            } catch (Exception e) {
                String msg = e.getMessage() == null? "" : e.getMessage();
                Log.e("DatabaseModel", "200 - Erro na operação no method del em Receitas DB"+msg);
            }
        }

        public boolean delete(@NonNull ReceitaModel receita) {
            try {
                SQLiteDatabase db = DatabaseModel.database.getWritableDatabase();

                if (db.delete(Tabela, ID+" = ?", new String[]{receita.getParseID()})>0)
                    return true;
                else
                    Log.e("DatabaseModel","Há algo de errado na operação delete: receita não foi removida");
            } catch (Exception e) {
                String msg = e.getMessage() == null? "" : e.getMessage();
                Log.e("DatabaseModel","Erro na operação delete em Receitas DB erro: "+msg);
            }
            return false;
        }

        public long update(@NonNull ReceitaModel receita) {
            if (receita.getID() == null) return -1;
            try {
                SQLiteDatabase db = DatabaseModel.database.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put(Titulo, receita.getTitulo());
                values.put(Descricao, receita.getDescricao());
                values.put(Tempo_preparo, receita.getTempo_preparo());
                values.put(Categoria, receita.getCategoria().getNome());
                if (receita.getUser().getID() != null)
                    values.put(User_ID, receita.getUser().getID());
                else if (user != null) {
                    values.put(User_ID, user.getID());
                }

                int rowsUpdated = db.update(Tabela, values, ID + " = ?", new String[]{receita.getParseID()});
                db.close();
                return rowsUpdated;
            } catch (Exception e) {
                String msg = e.getMessage() == null? "" : e.getMessage();
                Log.e("DatabaseModel","Erro na operação insertOrUpdate em Receitas DB erro: "+msg);
            }
            return -1;
        }

        public long insert(ReceitaModel receita) {
            try {
                SQLiteDatabase db = DatabaseModel.database.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put(Titulo, receita.getTitulo());
                values.put(Descricao, receita.getDescricao());
                values.put(Tempo_preparo, receita.getTempo_preparo());
                values.put(Categoria, receita.getCategoria().getNome());
                if (receita.getUser().getID() != null)
                    values.put(User_ID, receita.getUser().getID());
                else if (user != null) {
                    values.put(User_ID, user.getID());
                }

                // Senão, insere novo registro
                long id = db.insert(Tabela, null, values);
                db.close();
                Log.d("DatabaseModel","ID retorn insert: "+id);
                if (id > 0) receita.setID(id);
                return id;

            } catch (Exception e) {
                String msg = e.getMessage() == null? "" : e.getMessage();
                Log.e("DatabaseModel","Erro na operação insert em Receitas DB erro: "+msg);
                return -1;
            }
        }

        // Método para buscar todas as receitas
        public List<ReceitaModel> getAllRecipes() {
            List<ReceitaModel> receitas = new ArrayList<ReceitaModel>();

            try {
                SQLiteDatabase db = DatabaseModel.database.getReadableDatabase();
                Cursor cursor = db.rawQuery("SELECT * FROM " + Tabela, null);
                setCursor(cursor);
                while (cursorNext()) {
                    UserModel user_m = new User().getUserByID(getCursorLong(User_ID));
                    if (user_m == null)
                        throw new NullPointerException("uma receita está sem usuario definido");

                    user_m.setSenha(null); // limpando a senha

                    Long id = getCursorLong(ID);
                    String titulo = getCursorString(Titulo);
                    String descricao = getCursorString(Descricao);
                    String tempo_preparo = getCursorString(Tempo_preparo);
                    CategoriaModel categoria = new CategoriaModel(getCursorString(Categoria));

                    ReceitaModel receita = new ReceitaModel(id, titulo, descricao, tempo_preparo, categoria, user_m, getIngredientesPorReceita(id));
                    isFavorito(receita);
                    receitas.add(receita);
                    setCursor(cursor);
                }

                cursor.close();
                db.close();
            } catch (Exception e) {
                String msg = e.getMessage() == null? "" : e.getMessage();
                Log.e("DatabaseModel", "Erro na operação getAllRecipes em Receitas DB erro: "+msg);
            }
            return receitas;
        }

        // Método para buscar os ingredientes de uma receita específica
        public List<IngredientesModel> getIngredientesPorReceita(ReceitaModel receita) {

            String sql = "SELECT "+Ingredientes.TID()+", "+Ingredientes.TNome()+", "+ Ingredientes.TTipo() +", "+ ReceitasIngredientes.TQuantidade()+" "+
                    "FROM " + ReceitasIngredientes.Tabela + " " +
                    "INNER JOIN "+ Ingredientes.Tabela +" ON "+ ReceitasIngredientes.TIngrediente_ID() +" = "+ Ingredientes.TID()+" "+
                    "WHERE "+ ReceitasIngredientes.TReceita_ID() +" = ?";

            List<IngredientesModel> ingred = new ArrayList<IngredientesModel>();

            try {
                SQLiteDatabase db = DatabaseModel.database.getReadableDatabase();
                setCursor(db.rawQuery(sql, new String[]{receita.getParseID()}));

                while (cursorNext()) {
                    Long id = getCursorLong(ID);
                    String nome = getCursorString(Ingredientes.Nome);
                    String tipo = getCursorString(Ingredientes.Tipo);
                    String quantidade = getCursorString(ReceitasIngredientes.Quantidade);
                    ingred.add(new IngredientesModel(id, nome, tipo, quantidade));
                }
                closeCursor();
                db.close();
            } catch (Exception e) {
                String msg = e.getMessage() == null? "" : e.getMessage();
                Log.e("Erro na operação getIngredientesPorReceita em Receitas DB", msg);
            }
            return ingred;
        }
        public List<IngredientesModel> getIngredientesPorReceita(Long ID) {
            return getIngredientesPorReceita(new ReceitaModel().setID(ID));
        }

        // Método para verificar se uma receita está marcada como favorita
        public boolean isFavorito(UserModel user, ReceitaModel receita) {
            return new Favoritos().isFavorito(user, receita);
        }

        public boolean isFavorito(@NonNull ReceitaModel receita) {
            //return isFavorito(new SessionManager(context).getUser(), receita);
            return DatabaseModel.user != null && isFavorito(DatabaseModel.user, receita);
        }

        public boolean setMarkFavorito(@NonNull UserModel user, @NonNull ReceitaModel receita) {
            Favoritos favorito = new Favoritos();
            Log.d("DatabaseModel","markFavorito user.getID() "+user.getID()+" receita.getID() "+receita.getID());
            boolean ok = favorito.insert(user.getID(), receita.getID()) > 0;
            if (ok)
                receita.setMarkFavorite(true);
            return ok;
        }
        public boolean setMarkFavorito(@NonNull ReceitaModel receita) {
            if (DatabaseModel.user == null) return false;
            return setMarkFavorito(DatabaseModel.user, receita);
        }

        public boolean setDisMarkFavorito(@NonNull UserModel user, @NonNull ReceitaModel receita) {
            Favoritos favorito = new Favoritos();
            Log.d("DatabaseModel","disMarkFavorito user.getID() "+user.getID()+" receita.getID() "+receita.getID());
            boolean ok = favorito.delete(user.getID(), receita.getID()) > 0;
            if (ok)
                receita.setMarkFavorite(false);
            return ok;
        }
        public boolean setDisMarkFavorito(@NonNull ReceitaModel receita) {
            if (DatabaseModel.user == null) return false;
            return setDisMarkFavorito(DatabaseModel.user, receita);
        }

        public List<ReceitaModel> getRecipesByCategory(@NonNull CategoriaModel categoria) {
            List<ReceitaModel> receitas = new ArrayList<>();
            try {
                String sql = "SELECT * FROM " + Tabela + " WHERE " + Categoria + " = ?";
                SQLiteDatabase db = DatabaseModel.database.getReadableDatabase();

                Cursor cursor = db.rawQuery(sql, new String[]{categoria.getNome()});
                setCursor(cursor);

                while (cursorNext()) {
                    ReceitaModel receita = new ReceitaModel();
                    UserModel user_m = new User().getUserByID(getCursorLong(User_ID));
                    user_m.setSenha(null);

                    receita.setID(getCursorLong(ID));
                    receita.setUser(user_m);
                    receita.setTitulo(getCursorString(Titulo));
                    receita.setDescricao(getCursorString(Descricao));
                    receita.setTempo_preparo(getCursorString(Tempo_preparo));
                    receita.setCategoria(new CategoriaModel(getCursorString(Categoria)));
                    receita.setIngredientes(getIngredientesPorReceita(getCursorLong(ID)));

                    if (user != null)
                        isFavorito(user, receita);

                    receitas.add(receita);
                    setCursor(cursor);
                }
                db.close();
                closeCursor();
            } catch (Exception e) {
                String msg = e.getMessage() == null? "" : e.getMessage();
                Log.e("Erro na operação getReceipeByCategory em Receitas DB", msg);
            }
            return receitas;
        }

        public List<ReceitaModel> getRecipesByUser(@NonNull UserModel userModel) {
            List<ReceitaModel> receitas = new ArrayList<>();
            try {
                String sql = "SELECT * FROM " + Tabela + " WHERE " + User_ID + " = ?";
                SQLiteDatabase db = DatabaseModel.database.getReadableDatabase();

                Cursor cursor = db.rawQuery(sql, new String[]{userModel.getParseID()});
                setCursor(cursor);

                while (cursorNext()) {
                    ReceitaModel receita = new ReceitaModel();
                    UserModel user_m = new User().getUserByID(getCursorLong(User_ID));
                    user_m.setSenha(null);

                    receita.setID(getCursorLong(ID));
                    receita.setUser(user_m);
                    receita.setTitulo(getCursorString(Titulo));
                    receita.setDescricao(getCursorString(Descricao));
                    receita.setTempo_preparo(getCursorString(Tempo_preparo));
                    receita.setCategoria(new CategoriaModel(getCursorString(Categoria)));
                    receita.setIngredientes(getIngredientesPorReceita(getCursorLong(ID)));

                    isFavorito(userModel, receita);

                    receitas.add(receita);
                    setCursor(cursor);
                }

                cursor.close();
                db.close();
            } catch (Exception e) {
                String msg = e.getMessage() == null? "" : e.getMessage();
                Log.e("Erro na operação getReceipeByCategory em Receitas DB", msg);
            }
            return receitas;
        }

        public List<ReceitaModel> getAllFavoriteRecipes(UserModel user) {
            List<ReceitaModel> receitas = new ArrayList<>();
            try {
                SQLiteDatabase db = DatabaseModel.database.getReadableDatabase();
                String sql = "select "+TALL()+" from "+Favoritos.Tabela+" inner join "+Tabela+" on "+Favoritos.TReceita_ID()+" = "+TID()+" where "+Favoritos.TUser_ID()+" = ?";

                Cursor cursor = db.rawQuery(sql, new String[] {user.getParseID()});
                setCursor(cursor);

                while (cursorNext()) {
                    UserModel user_m = new User().getUserByID(getCursorLong(User_ID));
                    user_m.setSenha(null); // limpando a senha
                    Log.d("DatabaseModel", "getAllFavoriteRecipes loop ");
                    Long id = getCursorLong(ID);
                    String titulo = getCursorString(Titulo);
                    String descricao = getCursorString(Descricao);
                    String tempo_preparo = getCursorString(Tempo_preparo);
                    CategoriaModel categoria = new CategoriaModel(getCursorString(Categoria));

                    ReceitaModel receita = new ReceitaModel(id, titulo, descricao, tempo_preparo, categoria, user_m, getIngredientesPorReceita(id));
                    isFavorito(user, receita);

                    receitas.add(receita);
                    setCursor(cursor);
                }
                db.close();
                closeCursor();
            } catch (Exception e) {
                Log.e("DatabaseModel", "Erro na operação getAllFavoriteRecipes erro: "+e.getMessage());
                throw new RuntimeException(e);
            }
            return receitas;
        }
        public List<ReceitaModel> getAllFavoriteRecipes() {
            return  getAllFavoriteRecipes(user);
        }
    }
    public Receitas getReceitas(SQLiteDatabase db) {
        return new Receitas(db);
    }
    public Receitas getReceitas() {
        return new Receitas();
    }

    public static class Ingredientes extends Model {

        public static final String Tabela = "ingredientes";
        public static final String ID = "id";
        public static final String Nome = "nome";
        public static final String Tipo = "tipo";

        public static String TID() { return Tabela+"."+ID; }
        public static String TNome() { return Tabela+"."+Nome; }
        public static String TTipo() { return Tabela+"."+Tipo; }

        private static final String CT = "CREATE TABLE "+Tabela+" (" +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Nome + " TEXT UNIQUE, " +
                Tipo + " TEXT)";

        public Ingredientes(SQLiteDatabase db) {
            super(CT, db);
        }
        public Ingredientes() {super();}

        /**
         * Retorna o ID se a operação for bem sucedida se não -1 se houver algum erro
         * @param nome String
         * @return long
         */
        public long insert(String nome, String tipo) {
            SQLiteDatabase db = DatabaseModel.database.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(Nome, nome);
            values.put(Tipo, tipo);
            try {
                return db.insertWithOnConflict(Tabela, null, values, SQLiteDatabase.CONFLICT_IGNORE);
            } catch (SQLiteConstraintException e) {
                Log.e("DB", "Ingrediente já existe: " + e.getMessage());
            }
            return -1;
        }

        public List<IngredientesModel> getTodaListaIngredientes(String filtrarPorTipo) {
            String sql = "SELECT * FROM " + Tabela;
            if (filtrarPorTipo != null) sql += " where "+Tipo+" = ?";
            String[] args = filtrarPorTipo != null? new String[] {filtrarPorTipo} : null;
            SQLiteDatabase db = DatabaseModel.database.getReadableDatabase();
            setCursor(db.rawQuery(sql, args));
            List<IngredientesModel> ingredientesList = new ArrayList<>();

            while (cursorNext()) {
                Long id = getCursorLong(ID);
                String nome = getCursorString(Nome);
                String tipo = getCursorString(Tipo);
                ingredientesList.add(new IngredientesModel(id, nome, tipo, null));
            }

            closeCursor();
            db.close();
            return ingredientesList;
        }

//        public List<IngredientesModel> getListarIngredientesPorTipo(String tipo_ingrediente) {
//            String sql = "SELECT * FROM " + Tabela +" WHERE " + Tipo + " = ?";
//            SQLiteDatabase db = DatabaseModel.database.getReadableDatabase();
//            setCursor(db.rawQuery(sql, new String[]{tipo_ingrediente}));
//            List<IngredientesModel> ingredientesList = new ArrayList<>();
//
//            while (cursorNext()) {
//                Long id = getCursorLong(ID);
//                String nome = getCursorString(Nome);
//                String tipo = getCursorString(Tipo);
//                ingredientesList.add(new IngredientesModel(id, nome, tipo, null));
//            }
//
//            closeCursor();
//            db.close();
//            return ingredientesList;
//        }

        public List<String> getListaDeTiposIngredientes() {
            SQLiteDatabase db = DatabaseModel.database.getReadableDatabase();
            setCursor(db.rawQuery("SELECT DISTINCT "+Tipo+" FROM "+Tabela, null));
            List<String> tipos_ingredientes = new ArrayList<>();
            while (cursorNext()) {
                tipos_ingredientes.add(getCursorString(Tipo));
            }
            closeCursor();
            db.close();
            return tipos_ingredientes;
        }
    }
    public Ingredientes getIngredientes(SQLiteDatabase db) { return new Ingredientes(db); }
    public Ingredientes getIngredientes() {
        return new Ingredientes();
    }

    public static class Categorias extends Model {

        public static final String Tabela = "categorias";
        public static final String Nome = "nome";

        private static final String CT = "CREATE TABLE "+Tabela+" (" +
                Nome + " TEXT PRIMARY KEY)";

        public Categorias(SQLiteDatabase db) {
            super(CT, db);
        }
        public Categorias() {
            super();
        }

        /**
         * Retorna o ID se a operação for bem sucedida se não -1 se houver algum erro
         * @param nome String
         * @return long
         */
        public long insert(String nome) {
            try {
                SQLiteDatabase db = DatabaseModel.database.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put(Nome, nome);
                long Result = db.insertWithOnConflict(Tabela, null, values, SQLiteDatabase.CONFLICT_IGNORE);
                db.close();
                return Result;
            } catch (Exception e) {
                String msg = e.getMessage() == null? "" : e.getMessage();
                Log.e("Erro na operação insert em Categorias DB", msg);
                return -1;
            }
        }

        public List<CategoriaModel> obterCategorias(String filtrarPorNome) {
            String sql = "SELECT "+Nome+" FROM "+Tabela;
            sql = filtrarPorNome != null? " where "+Nome+" = ?" : sql;
            String[] args = filtrarPorNome!=null? new String[] {filtrarPorNome} : null;
            List<CategoriaModel> categorias = new ArrayList<>();
            try {
                SQLiteDatabase db = DatabaseModel.database.getReadableDatabase();
                setCursor(db.rawQuery(sql, args));

                while (cursorNext()) {
                    categorias.add(new CategoriaModel(getCursorString(Nome)));
                }

                closeCursor();
                db.close();
            } catch (Exception e) {
                String msg = e.getMessage() == null? "" : e.getMessage();
                Log.e("Erro na operação obterCategorias em Categorias DB", msg);
            }
            return categorias;
        }
        public List<CategoriaModel> obterCategorias() { return obterCategorias(null); }
    }
    public Categorias getCategorias(SQLiteDatabase db) {
        return new Categorias(db);
    }
    public Categorias getCategorias() {
        return new Categorias();
    }

    public static class ReceitasIngredientes extends Model {

        public SQLiteDatabase db;

        public static final String Tabela = "receitas_ingredientes";
        public static final String ID = "id";
        public static final String Receita_ID = "recipe_id";
        public static final String Ingrediente_ID = "ingrediente_id";
        public static final String Quantidade = "quantidade";

        public static String TID() { return Tabela+"."+ID; }
        public static String TReceita_ID() { return Tabela+"."+Receita_ID; }
        public static String TIngrediente_ID() { return Tabela+"."+Ingrediente_ID; }
        public static String TQuantidade() { return Tabela+"."+Quantidade; }

        private static final String CT = "CREATE TABLE "+Tabela+" (" +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Receita_ID + " INTEGER, " +
                Ingrediente_ID + " INTEGER, " +
                Quantidade + " TEXT, " +
                "UNIQUE("+Receita_ID+", "+Ingrediente_ID+"), "+
                "FOREIGN KEY("+Receita_ID+") REFERENCES "+Receitas.Tabela+"("+Receitas.ID+"), " +
                "FOREIGN KEY("+Ingrediente_ID+") REFERENCES "+Ingredientes.Tabela+"("+Ingredientes.ID+"))";

        public ReceitasIngredientes(SQLiteDatabase db) {
            super(CT, db);
        }
        public ReceitasIngredientes() {super();}

        public long associar(Long receita_ID, Long ingrediente_ID, String quantidade) {
            db = null;
            try {
                db = DatabaseModel.database.getWritableDatabase();
                db.beginTransaction();  // Desativa o commit automático

                ContentValues values = new ContentValues();
                values.put(Receita_ID, receita_ID);
                values.put(Ingrediente_ID, ingrediente_ID);
                values.put(Quantidade, quantidade);

                // Tentativa de atualização
                int rows = db.update(Tabela, values,
                        Receita_ID + " = ? AND " + Ingrediente_ID + " = ?",
                        new String[]{String.valueOf(receita_ID), String.valueOf(ingrediente_ID)});

                // Se não atualizou nada, insere
                if (rows == 0) {
                    return db.insert(Tabela, null, values);
                }
            } catch (Exception e) {
                String message = e.getMessage();
                message = message == null? "" : message;
                Log.e("Erro em associar ingrediente", message);
                return -1;
            }
            return 0;
        }

        public void removerAssociacoes(ReceitaModel receita, List<Long> ingredientesIds) {
            db = null;
            try {
                db = DatabaseModel.database.getWritableDatabase();

                for (Long ingredienteId : ingredientesIds) {
                    db.delete(Tabela,
                            Receita_ID + " = ? AND " + Ingrediente_ID + " = ?",
                            new String[]{receita.getParseID(), String.valueOf(ingredienteId)});
                }
            } catch (Exception e) {
                String msg = e.getMessage() == null? "" : e.getMessage();
                Log.e("Erro na operação removerAssociacoes em ReceitasIngredientes DB", msg);
            }
        }

        public void commit() {
            if (db == null) return;
            db.setTransactionSuccessful();
            db.endTransaction();
            db.close();
        }

        public void rollback() {
            if (db == null) return;
            db.endTransaction();
            db.close();
        }
    }
    public ReceitasIngredientes getReceitasIngredientes(SQLiteDatabase db) {
        return new ReceitasIngredientes(db);
    }
    public ReceitasIngredientes getReceitasIngredientes() {
        return new ReceitasIngredientes();
    }

    public static class Favoritos extends Model {

        public static final String Tabela = "favoritos";
        public static final String User_ID = "user_id";
        public static final String Receita_ID = "recipe_id";

        public static String TUser_ID() {
            return Tabela+"."+User_ID;
        }
        public static String TReceita_ID() {
            return Tabela+"."+Receita_ID;
        }

        private static final String CT = "CREATE TABLE "+Tabela+" (" +
                User_ID + " INTEGER, " +
                Receita_ID + " INTEGER, " +
                "FOREIGN KEY("+User_ID+") REFERENCES "+User.Tabela+"("+User.ID+") ON DELETE CASCADE, " +
                "FOREIGN KEY("+Receita_ID+") REFERENCES "+Receitas.Tabela+"("+Receitas.ID+") ON DELETE CASCADE)," +
                "UNIQUE("+User_ID+", "+Receita_ID+")";

        public Favoritos(SQLiteDatabase db) {
            super(CT, db);
        }
        public Favoritos() {super();}

        /**
         * Retorna o ID se a operação for bem sucedida se não -1 se houver algum erro
         * @param user_ID long
         * @param receita_ID long
         * @return long
         */
        public long insert(Long user_ID, Long receita_ID) {
            try {
                SQLiteDatabase db = DatabaseModel.database.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put(User_ID, user_ID);
                values.put(Receita_ID, receita_ID);
                long id = db.insertWithOnConflict(Tabela, null, values, SQLiteDatabase.CONFLICT_IGNORE);
                db.close();
                return id;
            } catch (Exception e) {
                String msg = e.getMessage() == null? "" : e.getMessage();
                Log.e("DatabaseModel", "Erro na operação insert em Favoritos DB erro: "+msg);
            }
            return -1;
        }

        private boolean isFavorito(UserModel user, ReceitaModel receita) {
            try {
                SQLiteDatabase db = DatabaseModel.database.getReadableDatabase();

//                Cursor cursor = db.query(Favoritos.Tabela, null, Favoritos.User_ID + " = ? AND " + Favoritos.Receita_ID + " = ? ",
//                        new String[]{user.getParseID(), receita.getParseID()}, null, null, null);

                String[] args = new String[] {user.getParseID(), receita.getParseID()};
                Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM "+Tabela+" WHERE "+User_ID+" = ? and "+Receita_ID+" = ?", args);
                cursor.moveToNext();
                boolean isFav = cursor.getLong(0)>0;//cursor.moveToNext();
                receita.setMarkFavorite(isFav);
                cursor.close();
                db.close();
                return isFav;
            } catch (Exception e) {
                String msg = e.getMessage() == null? "" : e.getMessage();
                Log.e("DatabaseModel", "Erro na operação isFavorito em Favoritos DB erro: "+msg);
                return false;
            }
        }

        public int del() {
            try {
                SQLiteDatabase db = DatabaseModel.database.getWritableDatabase();
                return db.delete(Tabela, null, null);
            } catch (Exception e) {
                String msg = e.getMessage() == null? "" : e.getMessage();
                Log.e("DatabaseModel", "Erro na operação delete em Favoritos DB erro: "+msg);
                return -1;
            }
        }

        public int delete(Long user_ID, Long receita_ID) {
            try {
                SQLiteDatabase db = DatabaseModel.database.getWritableDatabase();
                String[] whereArg = new String[]{
                        String.valueOf(receita_ID),
                        String.valueOf(user_ID)
                };
                int rows = db.delete(Tabela, Receita_ID+" = ? and "+User_ID+" = ?", whereArg);
                db.close();
                return rows;
            } catch (Exception e) {
                String msg = e.getMessage() == null? "" : e.getMessage();
                Log.e("DatabaseModel", "Erro na operação delete em Favoritos DB erro: "+msg);
                return -1;
            }
        }

    }
    public Favoritos getFavoritos(SQLiteDatabase db) {
        return new Favoritos(db);
    }
    public Favoritos getFavoritos() {
        return new Favoritos();
    }
}
