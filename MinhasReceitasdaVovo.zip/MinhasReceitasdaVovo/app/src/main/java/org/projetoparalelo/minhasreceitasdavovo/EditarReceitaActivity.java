package org.projetoparalelo.minhasreceitasdavovo;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.projetoparalelo.minhasreceitasdavovo.db.DatabaseHelpe;
import org.projetoparalelo.minhasreceitasdavovo.db.model.CategoriaModel;
import org.projetoparalelo.minhasreceitasdavovo.db.model.DatabaseModel;
import org.projetoparalelo.minhasreceitasdavovo.db.model.IngredientesModel;
import org.projetoparalelo.minhasreceitasdavovo.db.model.ReceitaModel;
import org.projetoparalelo.minhasreceitasdavovo.util.FixLayout;
import org.projetoparalelo.minhasreceitasdavovo.util.SessionManager;
import org.projetoparalelo.minhasreceitasdavovo.util.Swipe;

import java.util.ArrayList;
import java.util.List;

public class EditarReceitaActivity extends AppCompatActivity {

    private LinearLayout containerIngredientes;
    private LayoutInflater inflater;

    private DatabaseHelpe databaseHelpe;
    private DatabaseModel.ReceitasIngredientes receitasIngredientes;
    private ReceitaModel receitaModel;

    private SessionManager sessionManager;

    private String tag = "EditarReceita_debug";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_receita);
        getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        sessionManager = new SessionManager(this);

        if (!sessionManager.isLoggedIn()) {
            finish();
            return;
        }

        ((TextView) findViewById(R.id.textViewVoltar)).setOnClickListener(v -> {
            finish();
        });
        TextView sigla_perfil = findViewById(R.id.sigla_perfil);
        sigla_perfil.setText(sessionManager.getUser().getSiglaNome());
        sigla_perfil.setOnClickListener(v -> {
            startActivity(new Intent(this, PerfilActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
            finish();
        });

        if (getIntent().hasExtra("recipe_object")) {
            Log.d(tag, "receitaModel esta nula");

            receitaModel = (ReceitaModel) getIntent().getSerializableExtra("recipe_object");

            if (receitaModel.getID() == null)
                return;
        } else
            return;

        databaseHelpe = new DatabaseHelpe(this, receitaModel.getUser());
        receitasIngredientes = databaseHelpe.Model().getReceitasIngredientes();

        containerIngredientes = findViewById(R.id.containerIngredientes);
        inflater = LayoutInflater.from(this);

        List<IngredientesModel> ingredientesList = receitaModel.getIngredientes();
        if (!ingredientesList.isEmpty()) {
            for (IngredientesModel ingrediente : ingredientesList)
                adicionarLayoutIngrediente(ingrediente);
        } else
            adicionarLayoutIngrediente();

        EditText edt_titulo = findViewById(R.id.edt_titulo);
        edt_titulo.setText(receitaModel.getTitulo());

        EditText edt_tempo_preparo = findViewById(R.id.edt_tempo_preparo);
        edt_tempo_preparo.setText(receitaModel.getTempo_preparo());

        EditText edt_descricao = findViewById(R.id.edt_descricao);
        edt_descricao.setText(receitaModel.getDescricao());

        Spinner list_categoria = findViewById(R.id.list_categoria);
        List<CategoriaModel> dados = databaseHelpe.Model().getCategorias().obterCategorias();
        ArrayAdapter<CategoriaModel> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, dados);
        list_categoria.setAdapter(adapter);

        setSpinner(list_categoria, receitaModel.getCategoria());

        Button btnUpdate = findViewById(R.id.btnUpdate);
        btnUpdate.setOnClickListener(v -> {
            if (receitaModel != null) {
                String titulo = edt_titulo.getText().toString();
                String tempo_preparo = edt_tempo_preparo.getText().toString();
                CategoriaModel categoria = (CategoriaModel) list_categoria.getSelectedItem();
                String descricao = edt_descricao.getText().toString();

                boolean validar = !(verificarCampoVazio(edt_titulo) &&
                        verificarCampoVazio(edt_tempo_preparo) &&
                        verificarCampoVazio(list_categoria));
                        //verificarCampoVazio(edt_descricao));

                if (validar) {
                    if (associarIngredientesAReceita()) {
                        receitaModel.setTitulo(titulo);
                        receitaModel.setTempo_preparo(tempo_preparo);
                        receitaModel.setCategoria(categoria);
                        receitaModel.setDescricao(descricao);
                        if (databaseHelpe.Model().getReceitas().update(receitaModel) > 0) {
                            Log.d(tag, "salvou as alterações no banco de dados");
                            Intent resultIntent = new Intent();
                            resultIntent.putExtra("receita_atualizada", receitaModel);
                            setResult(RESULT_OK, resultIntent);
                            finish();
                        } else
                            Log.d(tag, "Algo de errado, não salvou as alterações no banco de dados");
                    }
                }
            }
        });

        View rootView = findViewById(R.id.scrollview);
        new Swipe(this, rootView, null, ReceitaDetalheActivity.class, Swipe.OnlyFinishRight);
        View layoutContentLeft = findViewById(R.id.layoutContentLeft);
        new Swipe(this, layoutContentLeft, null, ReceitaDetalheActivity.class, Swipe.OnlyFinishRight);
        FixLayout.ajustarLayoutBarrasSwipe(this);

    }

    private void adicionarLayoutIngrediente() { adicionarLayoutIngrediente(null); }
    private void adicionarLayoutIngrediente(IngredientesModel ingredientesModel) {
        // Antes de adicionar o novo, remova o botão de "adicionar" do anterior, se houver
        int count = containerIngredientes.getChildCount();
        if (count > 0) {
            View ultimoBloco = containerIngredientes.getChildAt(count - 1);
            ImageButton btnAddAnterior = ultimoBloco.findViewById(R.id.btn_add_ingrediente);
            btnAddAnterior.setVisibility(View.GONE);  // Oculta o botão "Adicionar" do bloco anterior
        }

        // Infla nova view do layout ingrediente
        View novoIngrediente = inflater.inflate(R.layout.ingrediente_item, containerIngredientes, false);

        Spinner spinnerIngredientes = novoIngrediente.findViewById(R.id.list_ingrediente);
        if (setIngredientesSpinner(spinnerIngredientes, null)) {
            setSpinner(spinnerIngredientes, ingredientesModel);
//            spinnerIngredientes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//                @Override
//                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                    IngredientesModel ingrediente = (IngredientesModel) parent.getItemAtPosition(position);
//
//                }
//
//                @Override
//                public void onNothingSelected(AdapterView<?> parent) {
//                    // Nada necessário aqui
//                }
//            });
        }

        EditText edt_quantidade = novoIngrediente.findViewById(R.id.edt_quantidade);
        if (ingredientesModel != null)
           edt_quantidade.setText(ingredientesModel.getQuantidade());

        ImageButton btnFiltrar = novoIngrediente.findViewById(R.id.btn_filtrar_ingredientes);

        List<String> tipos = databaseHelpe.Model().getIngredientes().getListaDeTiposIngredientes();
        tipos.add(0, "Todos");

        Spinner spinnerTipos = novoIngrediente.findViewById(R.id.list_tipos);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(novoIngrediente.getContext(), android.R.layout.simple_spinner_item, tipos);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTipos.setAdapter(adapter);

        if (adapter.getCount() > 0)
            spinnerTipos.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    String tipoSelecionado = parent.getItemAtPosition(position).toString();
                    if (tipoSelecionado.equals("Todos")) {
                        setIngredientesSpinner(spinnerIngredientes, null);

                        spinnerTipos.setVisibility(View.GONE);
                        btnFiltrar.setVisibility(View.VISIBLE); // mostra o botão de novo
                    } else {
                        setIngredientesSpinner(spinnerIngredientes, tipoSelecionado);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    // Nada necessário aqui
                }
            });

        btnFiltrar.setOnClickListener(v -> {
            if (spinnerTipos.getVisibility() == View.GONE) {
                spinnerTipos.setVisibility(View.VISIBLE);
                btnFiltrar.setVisibility(View.GONE);
            }
        });

        ImageButton btnExcluir = novoIngrediente.findViewById(R.id.btn_apagar_ingrediente);
        if (count == 0)
            btnExcluir.setVisibility(View.GONE);
        else {
            // Configura botão de remover
            btnExcluir.setOnClickListener(v -> {
                containerIngredientes.removeView(novoIngrediente);
                restaurarBotaoAdicionarNoUltimo(); // Recoloca o botão "Adicionar" no novo último
            });
        }

        ImageButton btnAdd = novoIngrediente.findViewById(R.id.btn_add_ingrediente);
        btnAdd.setOnClickListener(v -> adicionarLayoutIngrediente());

        // Adiciona novo bloco
        containerIngredientes.addView(novoIngrediente);
    }

    private void restaurarBotaoAdicionarNoUltimo() {
        int count = containerIngredientes.getChildCount();
        if (count > 0) {
            View ultimoBloco = containerIngredientes.getChildAt(count - 1);
            ImageButton btnAdd = ultimoBloco.findViewById(R.id.btn_add_ingrediente);
            btnAdd.setVisibility(View.VISIBLE); // Reexibe o botão "Adicionar" no último
        }
    }

    private boolean setIngredientesSpinner(@NonNull Spinner spinner, String filtrarPorTipo) {
        List<IngredientesModel> lista_ingredientes = databaseHelpe.Model().getIngredientes().getTodaListaIngredientes(filtrarPorTipo);
        ArrayAdapter<IngredientesModel> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, lista_ingredientes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        return adapter.getCount() > 0;
    }

    List<Long> idingredientesExcluidos;
    public boolean associarIngredientesAReceita() {

        Log.d(tag, "Entrou em associarIngredientesAReceita");

        if (receitaModel == null) return false;
        boolean camposVazios = false;
        int count = containerIngredientes.getChildCount();

        for (int i = 0; i < count; i++) {
            View bloco = containerIngredientes.getChildAt(i);
            Spinner spinnerIngrediente = bloco.findViewById(R.id.list_ingrediente);
            EditText edt_quantidade = bloco.findViewById(R.id.edt_quantidade);

            camposVazios = verificarCampoVazio(edt_quantidade) || verificarCampoVazio(spinnerIngrediente);

            IngredientesModel ingredientesModel = (IngredientesModel) spinnerIngrediente.getSelectedItem();

            Log.d(tag, "Campo não esta vazio: receitaModel.getID() "+receitaModel.getID()+" ingredientesModel.getID() "+ingredientesModel.getID());

            receitasIngredientes
                    .associar(receitaModel.getID(), ingredientesModel.getID(), edt_quantidade.getText().toString());
        }
        if (camposVazios)
            receitasIngredientes.rollback();
        else
            receitasIngredientes.commit();
        return !camposVazios;
    }

    private <T> void setSpinner(@NonNull Spinner spinner, T valorDesejado) {
        if (valorDesejado == null) return;
        ArrayAdapter<T> adapter = (ArrayAdapter<T>) spinner.getAdapter();
        for (int i = 0; i < adapter.getCount(); i++) {
            if (adapter.getItem(i).equals(valorDesejado)) {
                spinner.setSelection(i);
                break;
            }
        }
    }

    private boolean verificarCampoVazio(Object object) {
        boolean vazio = false;
        if (object instanceof EditText) {
            EditText campoText = (EditText) object;
            if (campoText.getText().toString().trim().isEmpty()) {
                campoText.setBackgroundResource(R.drawable.bg_button_erroalert);
                vazio = true;
            } else
                campoText.setBackgroundResource(R.drawable.bg_button_white);
        } else if (object instanceof Spinner) {
            Spinner campoSpinner = (Spinner) object;
            if (campoSpinner.getSelectedItem() == null) {
                campoSpinner.setBackgroundResource(R.drawable.bg_button_erroalert);
                vazio = true;
            } else
                campoSpinner.setBackgroundResource(R.drawable.bg_button_white);
        }
        if (vazio)
            new AlertDialog.Builder(this)
                    .setTitle("Campos obrigatórios")
                    .setMessage("Por favor, preencha todos os campos de ingrediente e quantidade.")
                    .setPositiveButton("OK", null)
                    .show();

        return vazio;
    }
}