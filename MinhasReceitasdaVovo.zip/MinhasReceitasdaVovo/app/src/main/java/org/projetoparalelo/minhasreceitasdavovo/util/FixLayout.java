package org.projetoparalelo.minhasreceitasdavovo.util;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.LinearLayout;
import org.projetoparalelo.minhasreceitasdavovo.R;

public class FixLayout {

//    public static void fixMenuTop(Activity activity) {
//        // Encontra as Views no layout
//        LinearLayout layoutMenuTop = activity.findViewById(R.id.layoutMenuTop);
//        LinearLayout layoutContent = activity.findViewById(R.id.layoutContent);
//
//        // Usa o ViewTreeObserver para esperar até que o layout esteja pronto
//        layoutMenuTop.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
//            @Override
//            public void onGlobalLayout() {
//                // Remove o listener para evitar chamadas repetidas
//                layoutMenuTop.getViewTreeObserver().removeOnGlobalLayoutListener(this);
//
//                // Obtém a altura de layoutMenuTop
//                int height = layoutMenuTop.getHeight();
//
//                // Define a margem superior em layoutContent
//                setMarginTop(layoutContent, height);
//            }
//        });
//    }

//    // Método auxiliar para definir a margem superior
//    private static void setMarginTop(View view, int marginTop) {
//        // Obtém os parâmetros de layout da View
//        ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
//
//        // Define a nova margem superior
//        params.topMargin = marginTop;
//
//        // Aplica os novos parâmetros à View
//        view.setLayoutParams(params);
//    }

    public static void ajustarLayoutBarrasSwipe(Activity activity) {
        LinearLayout layoutMenuTop = activity.findViewById(R.id.layoutMenuTop);
        LinearLayout layoutContentRight = activity.findViewById(R.id.layoutContentRight);
        LinearLayout layoutContentLeft = activity.findViewById(R.id.layoutContentLeft);

        // Espera até o layout ser desenhado para pegar a altura real
        layoutMenuTop.post(() -> {
            int altura = 0;
            ViewGroup.LayoutParams params = null;

            if (layoutContentRight != null) {
                // right
                altura = layoutMenuTop.getHeight();
                altura = layoutContentRight.getHeight() - (altura - 300);
                // Atualiza a altura
                params = layoutContentRight.getLayoutParams();
                params.height = altura;
                layoutContentRight.setLayoutParams(params);
            }

            if (layoutContentLeft != null) {
                // left
                altura = layoutMenuTop.getHeight();
                altura = layoutContentLeft.getHeight() - (altura - 300);

                params = layoutContentLeft.getLayoutParams();
                params.height = altura;
                layoutContentLeft.setLayoutParams(params);
            }
        });
    }

}
