package org.projetoparalelo.minhasreceitasdavovo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.projetoparalelo.minhasreceitasdavovo.db.DatabaseHelpe;
import org.projetoparalelo.minhasreceitasdavovo.db.model.ReceitaModel;
import org.projetoparalelo.minhasreceitasdavovo.db.model.UserModel;
import org.projetoparalelo.minhasreceitasdavovo.util.FixLayout;
import org.projetoparalelo.minhasreceitasdavovo.util.MenuHelp;
import org.projetoparalelo.minhasreceitasdavovo.util.MenuBarInferior;
import org.projetoparalelo.minhasreceitasdavovo.util.SessionManager;
import org.projetoparalelo.minhasreceitasdavovo.util.Swipe;

public class PerfilFavoritosActivity extends AppCompatActivity {

    private RecipeAdapter recipeAdapter;
    private SessionManager sessionManager;
    private DatabaseHelpe database;
    private MenuBarInferior menuInferior;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil_favoritos);
        getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        sessionManager = new SessionManager(this);
        if (!sessionManager.isLoggedIn()) {
            finish();
            return;
        }
        database = new DatabaseHelpe(this, sessionManager.getUser());

        TextView sigla_perfil = findViewById(R.id.sigla_perfil);
        sigla_perfil.setText(sessionManager.getUser().getSiglaNome());
        sigla_perfil.setOnClickListener(v -> {
            startActivity(new Intent(this, PerfilActivity.class)
                    .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
            finish();
        });

        menuInferior = new MenuBarInferior(this);

        RecyclerView recyclerViewRecipes = findViewById(R.id.recyclerViewRecipes);
        recyclerViewRecipes.setLayoutManager(new LinearLayoutManager(this));

        recipeAdapter = new RecipeAdapter(this, database.Model().getReceitas().getAllFavoriteRecipes(sessionManager.getUser()),
                new RecipeAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(ReceitaModel receita) {
                        // Abrir detalhes da receita
                        Intent intent = new Intent(PerfilFavoritosActivity.this, ReceitaDetalheActivity.class);
                        intent.putExtra("receita_object", receita);
                        intent.putExtra("de_onde_veio", PerfilFavoritosActivity.class.getSimpleName());
                        startActivity(intent);
                    }

                    @Override
                    public void onCheckChanged(ReceitaModel receita, boolean isChecked) {
                        UserModel user = sessionManager.getUser();
                        if (isChecked)
                            database.Model().getReceitas().setMarkFavorito(user, receita);
                        else {
                            database.Model().getReceitas().setDisMarkFavorito(user, receita);
                            recipeAdapter.atualizadarLista(database.Model().getReceitas().getAllFavoriteRecipes(sessionManager.getUser()));
                        }
                    }
                });
        recyclerViewRecipes.setAdapter(recipeAdapter);

        View rootView = findViewById(R.id.scrollview);
        new Swipe(this, rootView, PerfilActivity.class, MainActivity.class);
        View layoutContentRightView = findViewById(R.id.layoutContentRight);
        new Swipe(this, layoutContentRightView, PerfilActivity.class, null);
        View layoutContentLeft = findViewById(R.id.layoutContentLeft);
        new Swipe(this, layoutContentLeft, null, MainActivity.class);

        menuInferior.make(MenuHelp.DisableFavoritos);
        menuInferior.markMenuIcon(MenuHelp.IC_FAVORITO);
        FixLayout.ajustarLayoutBarrasSwipe(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        recipeAdapter.atualizadarLista(database.Model().getReceitas().getAllFavoriteRecipes(sessionManager.getUser()));
    }
}