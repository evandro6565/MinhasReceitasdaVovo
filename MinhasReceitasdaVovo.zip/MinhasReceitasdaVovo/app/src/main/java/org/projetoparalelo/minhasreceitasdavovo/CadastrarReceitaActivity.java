package org.projetoparalelo.minhasreceitasdavovo;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.bumptech.glide.Glide;

import org.projetoparalelo.minhasreceitasdavovo.db.DatabaseHelpe;
import org.projetoparalelo.minhasreceitasdavovo.db.model.CategoriaModel;
import org.projetoparalelo.minhasreceitasdavovo.db.model.DatabaseModel;
import org.projetoparalelo.minhasreceitasdavovo.db.model.IngredientesModel;
import org.projetoparalelo.minhasreceitasdavovo.db.model.ReceitaModel;
import org.projetoparalelo.minhasreceitasdavovo.db.model.UserModel;
import org.projetoparalelo.minhasreceitasdavovo.util.SessionManager;

import java.util.ArrayList;
import java.util.List;

public class CadastrarReceitaActivity extends AppCompatActivity {
    private DatabaseHelpe databaseHelpe;
    private ReceitaModel receitaModel;
    private DatabaseModel.ReceitasIngredientes receitasIngredientes;

    private ScrollView scrollview;
    private LinearLayout containerIngredientes, layoutCadSucess, layoutButoes;
    private LayoutInflater inflater;

    private List<Long> ID_ingredientesExcluidos;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar_receita);
        getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        sessionManager = new SessionManager(this);
        if (!sessionManager.isLoggedIn()) {
            finish();
            return;
        }

        ID_ingredientesExcluidos = new ArrayList<>();

        ((TextView) findViewById(R.id.textViewVoltar)).setOnClickListener(v -> {
            finish();
        });
        ((TextView) findViewById(R.id.sigla_perfil)).setOnClickListener(v -> {
            Intent intent = new Intent(this, PerfilActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });

        UserModel user = sessionManager.getUser();//(UserModel) getIntent().getSerializableExtra("user_object");
        databaseHelpe = new DatabaseHelpe(this, user);
        receitasIngredientes = databaseHelpe.Model().getReceitasIngredientes();
        receitaModel = new ReceitaModel();

        containerIngredientes = findViewById(R.id.containerIngredientes);
        inflater = LayoutInflater.from(this);

        EditText edt_titulo = findViewById(R.id.edt_titulo);

        EditText edt_tempo_preparo = findViewById(R.id.edt_tempo_preparo);

        EditText edt_descricao = findViewById(R.id.edt_descricao);

        Spinner list_categoria = findViewById(R.id.list_categoria);
        List<CategoriaModel> dados = databaseHelpe.Model().getCategorias().obterCategorias();
        ArrayAdapter<CategoriaModel> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, dados);
        list_categoria.setAdapter(adapter);

        layoutButoes = findViewById(R.id.layoutButoes);
        layoutButoes.setVisibility(View.GONE);

        Button btnSalvar = findViewById(R.id.btnSalvar);
        btnSalvar.setVisibility(View.VISIBLE);
        btnSalvar.setOnClickListener(v -> {
            if (receitaModel != null) {
                String titulo = edt_titulo.getText().toString();
                String tempo_preparo = edt_tempo_preparo.getText().toString();
                CategoriaModel categoria = (CategoriaModel) list_categoria.getSelectedItem();
                String descricao = edt_descricao.getText().toString();

                boolean validar = (!verificarCampoVazio(edt_titulo) &&
                        !verificarCampoVazio(edt_tempo_preparo) &&
                        !verificarCampoVazio(list_categoria)); //||
                        //verificarCampoVazio(edt_descricao));

                if (validar && !checkSeAListaDeIngredienteEstaVazia()) {
                    receitaModel.setTitulo(titulo);
                    receitaModel.setTempo_preparo(tempo_preparo);
                    receitaModel.setCategoria(categoria);
                    receitaModel.setDescricao(descricao);
                    receitaModel.setUser(sessionManager.getUser());
                    if (databaseHelpe.Model().getReceitas().insert(receitaModel) > 0) {
                        associarIngredientesAReceita();
                        Log.d("DatabaseModel", "Foi add ID para Receita: "+receitaModel.getParseID());
                        carregarGif();
                        btnSalvar.setVisibility(View.GONE);
                        layoutButoes.setVisibility(View.VISIBLE);
                    }
                }
            }
        });
        ((Button) findViewById(R.id.btnVoltar)).setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
            finish();
        });
        ((Button) findViewById(R.id.btnNovaReceita)).setOnClickListener(v -> {
            edt_titulo.setText("");
            edt_titulo.requestFocus();
            edt_tempo_preparo.setText("");
            list_categoria.setSelection(0);
            edt_descricao.setText("");

            layoutCadSucess.setVisibility(View.GONE);
            scrollview.setVisibility(View.VISIBLE);

            btnSalvar.setVisibility(View.VISIBLE);
            layoutButoes.setVisibility(View.GONE);
            receitaModel = new ReceitaModel();
            containerIngredientes.removeAllViews();
            adicionarLayoutIngrediente();
        });

        adicionarLayoutIngrediente();

        scrollview = findViewById(R.id.scrollview);
        scrollview.setVisibility(View.VISIBLE);
        layoutCadSucess = findViewById(R.id.layoutCadSucess);
        layoutCadSucess.setVisibility(View.GONE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        scrollview.setVisibility(View.VISIBLE);
        layoutCadSucess.setVisibility(View.GONE);
    }

    private void adicionarLayoutIngrediente() {
        // Antes de adicionar o novo, remova o botão de "adicionar" do anterior, se houver
        int count = containerIngredientes.getChildCount();
        if (count > 0) {
            View ultimoBloco = containerIngredientes.getChildAt(count - 1);
            ImageButton btnAddAnterior = ultimoBloco.findViewById(R.id.btn_add_ingrediente);
            btnAddAnterior.setVisibility(View.GONE);  // Oculta o botão "Adicionar" do bloco anterior
        }

        // Infla nova view do layout ingrediente
        View novoIngrediente = inflater.inflate(R.layout.ingrediente_item, containerIngredientes, false);

        Spinner spinnerIngredientes = novoIngrediente.findViewById(R.id.list_ingrediente);
        setIngredientesSpinner(spinnerIngredientes, null);

        //EditText edt_quantidade = novoIngrediente.findViewById(R.id.edt_quantidade);

        ImageButton btnFiltrar = novoIngrediente.findViewById(R.id.btn_filtrar_ingredientes);

        List<String> tipos = databaseHelpe.Model().getIngredientes().getListaDeTiposIngredientes();
        tipos.add(0, "-selecione um filtro-");
        tipos.add(1, "Todos");

        Spinner spinnerTipos = novoIngrediente.findViewById(R.id.list_tipos);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(novoIngrediente.getContext(), android.R.layout.simple_spinner_item, tipos);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTipos.setAdapter(adapter);

        if (adapter.getCount() > 0)
            spinnerTipos.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    String tipoSelecionado = parent.getItemAtPosition(position).toString();
                    if (tipoSelecionado.equals("Todos")) {
                        setIngredientesSpinner(spinnerIngredientes, null);

                        spinnerTipos.setVisibility(View.GONE);
                        btnFiltrar.setVisibility(View.VISIBLE); // mostra o botão de novo
                        spinnerTipos.setSelection(0);
                    } else {
                        setIngredientesSpinner(spinnerIngredientes, tipoSelecionado);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    // Nada necessário aqui
                }
            });

        btnFiltrar.setOnClickListener(v -> {
            //if (spinnerTipos.getVisibility() == View.GONE) {
                spinnerTipos.setVisibility(View.VISIBLE);
                btnFiltrar.setVisibility(View.GONE);
            //}
        });

        ImageButton btnExcluir = novoIngrediente.findViewById(R.id.btn_apagar_ingrediente);
        if (count == 0) {
            btnExcluir.setVisibility(View.GONE);  // Oculta o botão "excluir" do primeiro bloco
        } else {
            // Configura botão de remover
            btnExcluir.setOnClickListener(v -> {
                IngredientesModel ingredienteSelecionado = (IngredientesModel) spinnerIngredientes.getSelectedItem();
                Long id = ingredienteSelecionado.getID();
                containerIngredientes.removeView(novoIngrediente);
                ID_ingredientesExcluidos.add(id);
                restaurarBotaoAdicionarNoUltimo(); // Recoloca o botão "Adicionar" no novo último
            });
        }

        ImageButton btnAdd = novoIngrediente.findViewById(R.id.btn_add_ingrediente);
        btnAdd.setOnClickListener(v -> adicionarLayoutIngrediente());

        // Adiciona novo bloco
        containerIngredientes.addView(novoIngrediente);
    }

    private void restaurarBotaoAdicionarNoUltimo() {
        int count = containerIngredientes.getChildCount();
        if (count > 0) {
            View ultimoBloco = containerIngredientes.getChildAt(count - 1);
            ImageButton btnAdd = ultimoBloco.findViewById(R.id.btn_add_ingrediente);
            btnAdd.setVisibility(View.VISIBLE); // Reexibe o botão "Adicionar" no último
        }
    }

    private boolean setIngredientesSpinner(@NonNull Spinner spinner, String filtrarPorTipo) {
        List<IngredientesModel> lista_ingredientes = databaseHelpe.Model().getIngredientes().getTodaListaIngredientes(filtrarPorTipo);
        lista_ingredientes.add(0, new IngredientesModel() {
            @Override
            public String toString() {
                return "-Selecione um ingrediente-";
            }
        });
        ArrayAdapter<IngredientesModel> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, lista_ingredientes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        return adapter.getCount() > 0;
    }

    public void associarIngredientesAReceita() {
        String LogTag = "CadastrarReceita_debug";

        Log.d(LogTag, "Entrou em associarIngredientesAReceita");
        if (receitaModel == null) return;
        boolean camposVazios = false;
        int count = containerIngredientes.getChildCount();

        for (int i = 0; i < count; i++) {
            View bloco = containerIngredientes.getChildAt(i);
            Spinner spinnerIngrediente = bloco.findViewById(R.id.list_ingrediente);
            EditText edt_quantidade = bloco.findViewById(R.id.edt_quantidade);

            IngredientesModel ingredientesModel = (IngredientesModel) spinnerIngrediente.getSelectedItem();

            Log.d(LogTag, "Campo não esta vazio: receitaModel.getID() "+receitaModel.getID()+" ingredientesModel.getID() "+ingredientesModel.getID());

            receitasIngredientes
                    .associar(receitaModel.getID(), ingredientesModel.getID(), edt_quantidade.getText().toString());
        }
        try {
            receitasIngredientes.commit();
            Log.d(LogTag, "executou: commit" );
        } catch (Exception e) {
            Log.e("DB", "Erro no commit/rollback", e);
            receitasIngredientes.rollback();
            Log.d(LogTag, "executou: rollback" );
        }
    }

    private boolean checkSeAListaDeIngredienteEstaVazia() {
        int count = containerIngredientes.getChildCount();
        boolean camposVazios = false;
        for (int i = 0; i < count; i++) {
            View bloco = containerIngredientes.getChildAt(i);
            Spinner spinnerIngrediente = bloco.findViewById(R.id.list_ingrediente);
            EditText edt_quantidade = bloco.findViewById(R.id.edt_quantidade);

            if (verificarCampoVazio(edt_quantidade) || verificarCampoVazio(spinnerIngrediente, bloco))
                camposVazios = true;
        }
        return camposVazios;
    }

    private boolean verificarCampoVazio(Object object, View view) {
        boolean vazio = false;
        if (object instanceof EditText) {
            EditText campoText = (EditText) object;
            if (campoText.getText().toString().trim().isEmpty()) {
                campoText.setBackgroundResource(R.drawable.bg_button_erroalert);
                vazio = true;
            } else
                campoText.setBackgroundResource(R.drawable.bg_button_white);
        } else if (object instanceof Spinner) {
            Spinner campoSpinner = (Spinner) object;
            if (campoSpinner.getSelectedItem() == null) {
                campoSpinner.setBackgroundResource(R.drawable.bg_button_erroalert);
                vazio = true;
            } else if (view != null && campoSpinner.getSelectedItem().toString().equals("-Selecione um ingrediente-")) {
                view.setBackgroundResource(R.drawable.bg_button_erroalert);
                vazio = true;
            } else {
                campoSpinner.setBackgroundResource(R.drawable.bg_button_white);
                if (view != null) view.setBackground(null);
            }
        }
        if (vazio)
            new AlertDialog.Builder(this)
                    .setTitle("Campos obrigatórios")
                    .setMessage("Por favor, preencha todos os campos de ingrediente e quantidade.")
                    .setPositiveButton("OK", null)
                    .show();

        return vazio;
    }
    private boolean verificarCampoVazio(Object object) {
        return verificarCampoVazio(object, null);
    }

    private void carregarGif() {
        scrollview.setVisibility(View.GONE);
        layoutCadSucess.setVisibility(View.VISIBLE);
        ImageView gifImageView = findViewById(R.id.gifImageView);
        Glide.with(this)
                .asGif()
                .load(R.drawable.bubududu) // pode ser local ou URL
                .into(gifImageView);
    }
}