package org.projetoparalelo.minhasreceitasdavovo.db.model;

import androidx.annotation.NonNull;

import org.projetoparalelo.minhasreceitasdavovo.util.MD5;

import java.io.Serializable;
import java.util.Objects;

public class UserModel implements Serializable {

    private Long ID;
    private String Nome;
    private String Email;
    private String Senha;

    public UserModel(Long ID, String email, String nome, String senha) {
        this.ID = ID;
        Email = email;
        Nome = nome;
        Senha = senha;
    }

    public UserModel(String email, String nome, String senha) {
        Email = email;
        Nome = nome;
        Senha = senha;
    }

    public UserModel(String email, String pass) {
        Email = email;
        Senha = pass;
    }

    public UserModel(UserModel ref) {
        ID = ref.getID();
        Email = ref.getEmail();
        Nome = ref.getNome();
        Senha = ref.getSenha();
    }

    public boolean itsMe(UserModel user) {
        if (Objects.equals(this, user)) return true;

        if (this.ID != null && Objects.equals(user.getID(), this.ID))
            return true;
        return false;
    }

    public UserModel() {}

    public Long getID() { return ID; }

    /**
     * retorna -1 se ID estiver null
     * @return String
     */
    public String getParseID() {
        if (ID == null) return "-1";
        return String.valueOf(ID);
    }

    public void setID(Long ID) {
        this.ID = ID;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getNome() {
        return Nome;
    }

    public String getSiglaNome() {
        if (Nome != null && !Nome.isBlank())
            return Nome.substring(0, 1);
        return "Null";
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getSenha() {
        return Senha;
    }
    public String getMD5Senha() {
        return MD5.get(getSenha());
    }

    public void setSenha(String senha) {
        Senha = senha;
    }

    @NonNull
    @Override
    public String toString() {
        return getNome();
    }
}
