package org.projetoparalelo.minhasreceitasdavovo;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.projetoparalelo.minhasreceitasdavovo.db.DatabaseHelpe;
import org.projetoparalelo.minhasreceitasdavovo.db.model.ReceitaModel;
import org.projetoparalelo.minhasreceitasdavovo.util.SessionManager;

import java.util.List;

public class RecipeAdapter extends RecyclerView.Adapter<RecipeAdapter.RecipeViewHolder> {
    private List<ReceitaModel> receitaList;
    private OnItemClickListener listener;
    private SessionManager sessionManager;

    public interface OnItemClickListener {
        void onItemClick(ReceitaModel receita);
        void onCheckChanged(ReceitaModel receita, boolean isChecked);
    }

    public RecipeAdapter(Context context, List<ReceitaModel> receitaList, OnItemClickListener listener) {
        this.receitaList = receitaList;
        this.listener = listener;
        sessionManager = new SessionManager(context);
    }

    @NonNull
    @Override
    public RecipeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_receita, parent, false);
        CheckBox checkBoxFavorito = view.findViewById(R.id.checkboxFavorito);
        checkBoxFavorito.setVisibility(sessionManager.isLoggedIn()? View.VISIBLE : View.GONE);
        return new RecipeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecipeViewHolder holder, int position) {
        ReceitaModel receita = receitaList.get(position);
        holder.textViewTitle.setText(receita.getTitulo());
        holder.textViewDescription.setText(receita.getDescricao());
        holder.textViewTime.setText("Tempo de Preparo: " + receita.getTempo_preparo());
        holder.textViewCategoria.setText(receita.getCategoria().getNome());

        holder.textViewUser.setText("Por: " + receita.getUser().getNome());

        //holder.itemView.setOnClickListener(v -> listener.onItemClick(receita));
        holder.imgReceita.setOnClickListener(v -> listener.onItemClick(receita));
        holder.checkBoxFavorito.setVisibility(View.GONE);
        if (sessionManager.isLoggedIn()) {
            holder.checkBoxFavorito.setVisibility(View.VISIBLE);
            holder.checkBoxFavorito.setChecked(receita.isFavorite());
            holder.checkBoxFavorito.setOnCheckedChangeListener((buttonView, isChecked) -> {
                listener.onCheckChanged(receita, isChecked);
            });
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    public void atualizadarLista(@NonNull List<ReceitaModel> receitaList) {
        this.receitaList.clear();
        this.receitaList.addAll(receitaList);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return receitaList.size();
    }

    public static class RecipeViewHolder extends RecyclerView.ViewHolder {
        TextView textViewTitle, textViewDescription, textViewTime, textViewUser, textViewCategoria;
        CheckBox checkBoxFavorito;
        ImageView imgReceita;
        public RecipeViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewDescription = itemView.findViewById(R.id.textViewDescription);
            textViewTime = itemView.findViewById(R.id.textViewTime);
            textViewUser = itemView.findViewById(R.id.textViewUser);
            textViewCategoria = itemView.findViewById(R.id.textViewCategoria);
            checkBoxFavorito = itemView.findViewById(R.id.checkboxFavorito);
            imgReceita = itemView.findViewById(R.id.imgReceita);
        }
    }
}
