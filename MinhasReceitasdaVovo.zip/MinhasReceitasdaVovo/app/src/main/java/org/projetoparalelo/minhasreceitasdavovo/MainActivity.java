package org.projetoparalelo.minhasreceitasdavovo;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.projetoparalelo.minhasreceitasdavovo.db.DatabaseHelpe;
import org.projetoparalelo.minhasreceitasdavovo.db.model.CategoriaModel;
import org.projetoparalelo.minhasreceitasdavovo.db.model.ReceitaModel;
import org.projetoparalelo.minhasreceitasdavovo.db.model.UserModel;
import org.projetoparalelo.minhasreceitasdavovo.util.FixLayout;
import org.projetoparalelo.minhasreceitasdavovo.util.MenuBarInferior;
import org.projetoparalelo.minhasreceitasdavovo.util.MenuHelp;
import org.projetoparalelo.minhasreceitasdavovo.util.SessionManager;
import org.projetoparalelo.minhasreceitasdavovo.util.Swipe;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    //private RecyclerView recyclerViewRecipes;
    private DatabaseHelpe database;
    private RecipeAdapter recipeAdapter;
    private SessionManager sessionManager;
    private MenuBarInferior menuInferior;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        sessionManager = new SessionManager(this);

        database = new DatabaseHelpe(this, sessionManager.getUser());
        database.carregar();

        menuInferior = new MenuBarInferior(this);

        RecyclerView recyclerViewRecipes = findViewById(R.id.recyclerViewRecipes);
        recyclerViewRecipes.setLayoutManager(new LinearLayoutManager(this));

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        notNull(getSupportActionBar()).setTitle("");

        recipeAdapter = new RecipeAdapter(this, database.Model().getReceitas().getAllRecipes(),
                new RecipeAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(ReceitaModel receita) {
                        // Abrir detalhes da receita
                        Intent intent = new Intent(MainActivity.this, ReceitaDetalheActivity.class);
                        intent.putExtra("receita_object", receita);
                        intent.putExtra("de_onde_veio", MainActivity.class.getSimpleName());
                        startActivity(intent);
                        finish();
                    }

                    @Override
                    public void onCheckChanged(ReceitaModel receita, boolean isChecked) {
                        UserModel user = sessionManager.getUser();
                        if (isChecked)
                            database.Model().getReceitas().setMarkFavorito(user, receita);
                        else
                            database.Model().getReceitas().setDisMarkFavorito(user, receita);
                    }
                });
        recyclerViewRecipes.setAdapter(recipeAdapter);

        permiss();

        View rootView = findViewById(R.id.scrollview);
        new Swipe(this, rootView, PerfilFavoritosActivity.class, null);
        View layoutContentRightView = findViewById(R.id.layoutContentRight);
        new Swipe(this, layoutContentRightView, PerfilFavoritosActivity.class, null);

        menuInferior.make(MenuHelp.DisableHome);
        menuInferior.markMenuIcon(MenuHelp.IC_HOME);
        FixLayout.ajustarLayoutBarrasSwipe(this);
    }

    private void permiss() {
        UserModel user = sessionManager.getUser();

        TextView login_regis = findViewById(R.id.login_regis);
        login_regis.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, CadastrarContaActivity.class)
                    .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
        });
        login_regis.setVisibility(sessionManager.isLoggedIn()? View.GONE : View.VISIBLE);

        TextView sigla_perfil = findViewById(R.id.sigla_perfil);
        sigla_perfil.setVisibility(View.GONE);
        ImageButton btnAddReceita = findViewById(R.id.btnAddReceita);
        btnAddReceita.setVisibility(View.GONE);

        if (sessionManager.isLoggedIn()) {
            sigla_perfil.setVisibility(View.VISIBLE);
            sigla_perfil.setText(user.getSiglaNome());
            sigla_perfil.setOnClickListener(v -> {
                startActivity(new Intent(MainActivity.this, PerfilActivity.class)
                        .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
            });

            btnAddReceita.setVisibility(View.VISIBLE);
            btnAddReceita.setOnClickListener(v -> {
                startActivity(new Intent(MainActivity.this, CadastrarReceitaActivity.class)
                        .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        permiss();
        menuInferior.checkSession();
        List<ReceitaModel> receitas = database.Model().getReceitas().getAllRecipes();
        Log.d("Main-evandro", "receitas.size:  "+receitas.size());
        recipeAdapter.atualizadarLista(receitas);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_home, menu);

        List<CategoriaModel> categorias = database.Model().getCategorias().obterCategorias();

        int idBase = Menu.FIRST; // ID base única para itens dinâmicos

        for (int i = 0; i < categorias.size(); i++) {
            CategoriaModel categoria = categorias.get(i);

            menu.add(Menu.NONE, idBase + i, Menu.NONE, categoria.getNome())
                    //.setIcon(R.drawable.ic_category)
                    .setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        }

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        String titulo = item.getTitle().toString();

        // Caso tenha outros itens fixos no menu:
        if (id == R.id.item_menu_todos) {
            recipeAdapter.atualizadarLista(database.Model().getReceitas().getAllRecipes());
            return true;
        }

        // Verifica se é um item dinâmico
        if (id >= Menu.FIRST) {
            Toast.makeText(this, "Categoria selecionada: " + titulo, Toast.LENGTH_SHORT).show();
            List<ReceitaModel> list = database.Model().getReceitas()
                    .getRecipesByCategory(new CategoriaModel(titulo));
            recipeAdapter.atualizadarLista(list);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public <T> T notNull(T param) {
        if (param == null)
            throw new NullPointerException("Erro, nenhum toolbar foi instaciado no MainActivity");

        return param;
    }
}