package org.projetoparalelo.minhasreceitasdavovo;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.projetoparalelo.minhasreceitasdavovo.db.DatabaseHelpe;
import org.projetoparalelo.minhasreceitasdavovo.db.model.DatabaseModel;
import org.projetoparalelo.minhasreceitasdavovo.db.model.UserModel;
import org.projetoparalelo.minhasreceitasdavovo.util.EditTextM;
import org.projetoparalelo.minhasreceitasdavovo.util.InputHelp;
import org.projetoparalelo.minhasreceitasdavovo.util.SessionManager;

public class LoginActivity extends AppCompatActivity {

    private SessionManager sessionManager;
    private TextView txtSenhaErr;
    private DatabaseHelpe database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        sessionManager = new SessionManager(this);
        if (sessionManager.isLoggedIn()) {
            finish();
            return;
        }

        database = new DatabaseHelpe(this);
        DatabaseModel.User databaseUser = database.Model().getUser();

        EditTextM edtEmail = findViewById(R.id.edtEmail);
        EditTextM edtSenha = findViewById(R.id.edtSenha);

        edtEmail.enableEmail();
        edtSenha.enablePass(this);
        detectarAlteracao(edtEmail);
        detectarAlteracao(edtSenha);

        txtSenhaErr = findViewById(R.id.txtSenhaErr);
        txtSenhaErr.setVisibility(TextView.INVISIBLE);

        ((TextView) findViewById(R.id.txtCadastrar)).setOnClickListener(v -> {
            startActivity(new Intent(this, CadastrarContaActivity.class)
                    .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
        });

        Button btnEntrar = findViewById(R.id.btnEntrar);
        btnEntrar.setOnClickListener(v -> {
            if (edtEmail.validateEmail() && edtSenha.validatePass(false)) {
                txtSenhaErr.setVisibility(TextView.INVISIBLE);

                UserModel user = new UserModel(getStr(edtEmail), getStr(edtSenha));

                if (databaseUser.validar(user, DatabaseModel.User.VALIDAR_LOGIN)) {
                    sessionManager.loginSucess();
                    sessionManager.saveUser(user);
                    startActivity(new Intent(this, MainActivity.class)
                            .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
                    finish();
                } else {
                    txtSenhaErr.setText("Email ou senha invalidos!");
                    txtSenhaErr.setVisibility(TextView.VISIBLE);
                }
            } else {
                txtSenhaErr.setText("Campo senha vazio!");
                txtSenhaErr.setVisibility(TextView.VISIBLE);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private String getStr(EditTextM ed) {
        return ed.getText().toString();
    }

    private void detectarAlteracao(EditTextM editText) {
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (before > 0 || count > 0) {
                    // Inserção ou remoção detectada
                    //Log.d("EditText", "Inserido: " + s.subSequence(start, start + count));
                    txtSenhaErr.setVisibility(TextView.INVISIBLE);
                }
            }

            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });
    }

}