package org.projetoparalelo.minhasreceitasdavovo.util;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import org.projetoparalelo.minhasreceitasdavovo.MainActivity;
import org.projetoparalelo.minhasreceitasdavovo.PerfilActivity;
import org.projetoparalelo.minhasreceitasdavovo.PerfilFavoritosActivity;
import org.projetoparalelo.minhasreceitasdavovo.R;

public class MenuBarInferior extends MenuHelp {

    private Button btnFavoritos, btnInicio, btnPerfil;
    private Activity activity;
    private SessionManager sessionManager;

    private boolean botoesAdd;
    private int disableBTN;

    public MenuBarInferior(@NonNull Activity activity) {
        this.activity = activity;
        sessionManager = new SessionManager(activity);

        btnFavoritos = activity.findViewById(R.id.btnFavoritos);
        btnInicio = activity.findViewById(R.id.btnInicio);
        btnPerfil = activity.findViewById(R.id.btnPerfil);
        botoesAdd = false;
    }

    public void make(int disableBTN) {

        this.disableBTN = disableBTN;

        if (btnInicio == null) throw new NullPointerException("Erro MenuBarInferior btnInicio esta null");

        btnInicio.setVisibility(View.VISIBLE);
        if (R.id.btnInicio != disableBTN) {
            btnInicio.setOnClickListener(v -> {
                Intent intent = new Intent(activity, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                activity.startActivity(intent);
                activity.finish();
            });
        }

        checkSession();
    }

    public void markMenuIcon(int icon) {
        Drawable drawableF = ContextCompat.getDrawable(activity, R.drawable.ic_heart_hover_medio);
        if (IC_FAVORITO == icon)
            drawableF = ContextCompat.getDrawable(activity, R.drawable.ic_heart_filled);
        btnFavoritos.setCompoundDrawablesWithIntrinsicBounds(null, drawableF, null, null);

        Drawable drawableH = ContextCompat.getDrawable(activity, R.drawable.ic_home);
        if (IC_HOME == icon)
            drawableH = ContextCompat.getDrawable(activity, R.drawable.ic_home_filled);
        btnInicio.setCompoundDrawablesWithIntrinsicBounds(null, drawableH, null, null);

        Drawable drawableP = ContextCompat.getDrawable(activity, R.drawable.ic_user);
        if (IC_PERFIL == icon)
            drawableP = ContextCompat.getDrawable(activity, R.drawable.ic_user_filled);
        if (IC_PERFIL_EDITAR == icon)
            drawableP = ContextCompat.getDrawable(activity, R.drawable.ic_editar_pink);
        btnPerfil.setCompoundDrawablesWithIntrinsicBounds(null, drawableP, null, null);
    }

    public void checkSession() {

        if (btnFavoritos == null) throw new NullPointerException("Erro MenuBarInferior btnFavoritos esta null");

        btnFavoritos.setVisibility(View.VISIBLE);
        if (R.id.btnFavoritos != disableBTN && sessionManager.isLoggedIn()) {
            if (!botoesAdd) {
                btnFavoritos.setOnClickListener(v -> {
                    Intent intent = new Intent(activity, PerfilFavoritosActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    activity.startActivity(intent);
                    activity.finish();
                });
            }
        }
        if (!sessionManager.isLoggedIn()) {
            btnFavoritos.setVisibility(View.GONE);
        }

        if (btnPerfil == null) throw new NullPointerException("Erro MenuBarInferior btnPerfil esta null");

        btnPerfil.setVisibility(View.VISIBLE);
        if (R.id.btnPerfil != disableBTN && sessionManager.isLoggedIn()) {
            if (!botoesAdd) {
                btnPerfil.setOnClickListener(v -> {
                    Intent intent = new Intent(activity, PerfilActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    activity.startActivity(intent);
                    activity.finish();
                });
            }
        }
        if (!sessionManager.isLoggedIn()) {
            btnPerfil.setVisibility(View.GONE);
        }

        if (sessionManager.isLoggedIn()) {
            botoesAdd = true;
        }
    }
}
