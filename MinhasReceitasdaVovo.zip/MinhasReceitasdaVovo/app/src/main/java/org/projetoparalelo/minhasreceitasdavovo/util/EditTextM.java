package org.projetoparalelo.minhasreceitasdavovo.util;

import org.projetoparalelo.minhasreceitasdavovo.R;
import org.projetoparalelo.minhasreceitasdavovo.db.DatabaseHelpe;
import org.projetoparalelo.minhasreceitasdavovo.db.model.DatabaseModel;
import org.projetoparalelo.minhasreceitasdavovo.db.model.UserModel;

import android.app.Activity;
import android.content.Context;
import android.text.Editable;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatEditText;

public class EditTextM extends AppCompatEditText {
    private static int limiteMinSenha = 6;

    public EditTextM(Context context) {
        super(context);
        init();
    }

    public EditTextM(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public EditTextM(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
//        ImageButton btn = findViewById(getLabelFor());
//        new InputHelp().btnTogglePass(this,  btn);
    }

//    @Override
//    protected void onFinishInflate() {
    private void enableToggleButton(Activity a) {

        Log.d("DebugApp", "onFinishInflate chamado");

        int editTextSenhaID = getId();
        String editTextSenhaID_Name = getResources().getResourceEntryName(editTextSenhaID);
        Log.d("DebugApp", "editTextSenhaID_Name: "+editTextSenhaID_Name);

        String btnToggleName = "btnToggle_"+editTextSenhaID_Name;
        int btnToggleID = getResources().getIdentifier(btnToggleName, "id", getContext().getPackageName());
        Log.d("DebugApp", "btnToggleName: "+btnToggleName+" "+btnToggleID);

        Log.d("DebugApp", "comaparar_ids: \ngerardo_btnToggleName"+btnToggleID+" \nID_btn_senha: "+R.id.btnToggle_edtSenha+" \nID_btnConfirmarSenha: "+R.id.btnToggle_edtConfirmarSenha);

        // Agora é seguro buscar o ImageButton
        ImageButton btn = a.findViewById(btnToggleID);
        if (btn != null) {
            Log.d("DebugApp", "Botão encontrado: " + btn.toString());
            // Configura o botão para alternar a visibilidade da senha
            new InputHelp().btnTogglePass(this, btn);
        }
        else {
            Log.e("DebugApp", "Botão é NULL. Verifique o ID ou o XML.");
        }
    }

    public void enablePass(Activity a) {
        enableToggleButton(a);
        setHint("Digite sua Senha");
        setInputType(android.text.InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
    }
    public void enableConfirmPass(Activity a, @NonNull EditTextM ed) {
        enablePass(a);
        setHint("Confirme sua Senha");
        addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!getStr(getText()).equals( getStr(ed.getText()) )) {
                    setError("As senhas não são iguais.");
                } else if (!validatePass(true)) {
                    setError("As senhas não são iguais.");
                }
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    public void enableEmail(DatabaseHelpe database) {
        setHint("Digite seu e-mail");
        setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus && validateEmail(true)) {
                    String texto = getStr(getText());
                    texto = StrTool.removerEspaco(texto, StrTool.TUDO);
                    setText(texto);
                    setSelection(texto.length()); // Move o cursor para o final
                    checkEmailExist(database);
                }
            }
        });
    }
    public void enableEmail() {
        enableEmail(null);
    }

    private boolean checkEmailExist(DatabaseHelpe database) {
        if (database != null &&
                database.Model()
                        .getUser()
                        .validar(new UserModel(getStr(getText()), ""), DatabaseModel.User.VALIDAR_IF_EXIST)) {
            setError("Esse e-mail já está em uso!");
            return true;
        }
        return false;
    }

    public void formatarNomes() {
        addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Não faz nada aqui
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Não faz nada aqui
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Remove o listener temporariamente para evitar loops infinitos
                removeTextChangedListener(this);

                // Obtém o texto atual
                String texto = s.toString();

                // Remove espaço em branco no final
                //texto = StrTool.removerEspaco(texto, StrTool.FINAL);

                // Formata o texto para deixar apenas as iniciais em maiúsculas
                texto = StrTool.formatarIniciaisMaiusculas(texto);

                // Define o texto formatado de volta no EditText
                setText(texto);
                setSelection(texto.length()); // Move o cursor para o final

                // Reativa o listener
                addTextChangedListener(this);
            }
        });
        setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) { // Verifica se o EditText perdeu o foco
                    // Obtém o texto atual
                    String texto = getStr(getText());

                    // Remove espaço em branco no final
                    texto = StrTool.removerEspaco(texto, StrTool.FINAL);

                    // Formata o texto para deixar apenas as iniciais em maiúsculas
                    texto = StrTool.formatarIniciaisMaiusculas(texto);

                    // Define o texto formatado de volta no EditText
                    setText(texto);
                    setSelection(texto.length()); // Move o cursor para o final
                }
            }
        });
    }

    // Método para validar o e-mail
    public boolean isValidEmail() {
        String email = getText() != null ? getText().toString().trim() : "";
        return !TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    // Validação com erro visível
    private boolean validateEmail(boolean igFocus) {
        if (!isValidEmail()) {
            if (!igFocus) {
                setError("E-mail inválido");
                requestFocus();
            }
            return false;
        }
        setError(null);
        return true;
    }

    /**
     * verifica se o formato de email esta correto
     * @return boolean
     */
    public boolean validateEmail() {
        return validateEmail(false);
    }

    /**
     * verifica se o formato de email esta correto e se o email já existe
     * @param database
     * @return boolean
     */
    public boolean validateEmail(DatabaseHelpe database, SessionManager sessionManager) {
        boolean emailValido = false;
        boolean emailNaoExiste = false;
        boolean emailSemAteracao = false;
        if (validateEmail(false))
            emailValido = true;
        if (sessionManager.getUser().getEmail().equals(getText().toString()))
            emailSemAteracao = true;
        else if (!checkEmailExist(database))
            emailNaoExiste = true;

        return emailValido && (emailNaoExiste || emailSemAteracao);
    }

    /**
     * define {@code true} para {@link #validatePass} checar se, a senha está tamanho de {@value  #limiteMinSenha} caracteres e configura padroes para cadastro
     * @see #validatePass
     * */
    public static final boolean VALIDATE_CADASTRO = true;
    /**
     * define {@code false} para {@link #validatePass} checar se, a senha está tamanho de {@value  #limiteMinSenha} caracteres
     * @see #validatePass
     * */
    public static final boolean VALIDATE = false;

    /**
     * Usado para checar o campo senha
     * @param cadastro
     * @return boolean
     * {@link #validatePass}
     */
    public boolean validatePass(boolean cadastro) {
        if (cadastro) {
            boolean chk = getStr(getText()).length() >= limiteMinSenha;
            if (!chk) {
                setError("tem que ter no minimo " + limiteMinSenha + " caracteres.");
                requestFocus();
            }
            return chk;
        }
        return !getStr(getText()).isBlank();

    }

    private String getStr(Editable e) {
        if (e == null)
            return "";
        return e.toString();
    }

    public void setLimiteMinimoDaSenha(int limiteMinSenha) {
        this.limiteMinSenha = limiteMinSenha;
    }
}
/*
    Use esse XML do Password para criar esse componente
    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:background="@drawable/bg_arrendondado"
        android:paddingTop="2dp"
        android:paddingBottom="2dp"
        android:paddingLeft="1dp"
        android:paddingRight="1dp"
        android:gravity="center_horizontal"
        android:orientation="horizontal"
        android:layout_marginBottom="5dp">
        <androidx.appcompat.widget.AppCompatEditText
            android:id="@+id/edtSenha"
            android:layout_width="0dp"
            android:layout_height="48dp"
            android:layout_weight="4"
            android:hint="Senha"
            android:textStyle="bold"
            android:inputType="textPassword"
            android:textColor="#49454F"
            android:background="@drawable/bg_arrendondado_left"
            android:padding="10dp"
            android:labelFor="@id/btnToggleSenha"/>
        <ImageButton
            android:id="@+id/btnToggleSenha"
            android:layout_width="0dp"
            android:layout_height="48dp"
            android:layout_weight="1"
            android:text="@null"
            android:background="@drawable/bg_arrendondado_right"
            android:src="@drawable/ic_eye_view"/>
    </LinearLayout>

 */
