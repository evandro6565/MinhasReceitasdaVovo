package org.projetoparalelo.minhasreceitasdavovo.util;

import android.text.InputType;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.appcompat.widget.AppCompatEditText;

import org.projetoparalelo.minhasreceitasdavovo.R;

public class InputHelp {

    public void btnTogglePass(AppCompatEditText ed, ImageButton btn) {
        btn.setOnClickListener(v -> {
            if (ed.getInputType() == (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD)) {
                // Mostrar senha
                ed.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                btn.setImageResource(R.drawable.ic_eye_view); // olho aberto
            } else {
                // Ocultar senha
                ed.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                btn.setImageResource(R.drawable.ic_eye_hide); // olho fechado
            }
            // Move o cursor para o final
            ed.setSelection(ed.getText().length());
        });
    }

}
