package org.projetoparalelo.minhasreceitasdavovo;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import org.projetoparalelo.minhasreceitasdavovo.db.DatabaseHelpe;
import org.projetoparalelo.minhasreceitasdavovo.db.model.UserModel;
import org.projetoparalelo.minhasreceitasdavovo.util.EditTextM;
import org.projetoparalelo.minhasreceitasdavovo.util.MenuHelp;
import org.projetoparalelo.minhasreceitasdavovo.util.MenuBarInferior;
import org.projetoparalelo.minhasreceitasdavovo.util.SessionManager;

public class PerfilEditarActivity extends AppCompatActivity {

    private SessionManager sessionManager;
    private DatabaseHelpe database;
    private TextView txtMsg;
    private UserModel user;
    private MenuBarInferior menuInferior;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil_editar);
        getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        sessionManager = new SessionManager(this);
        if (!sessionManager.isLoggedIn()) {
            finish();
            return;
        }

        menuInferior = new MenuBarInferior(this);

        database = new DatabaseHelpe(this, sessionManager.getUser());
        user = sessionManager.getUser();
        user = database.Model().getUser().getUserByID(user.getID()); // checagem com banco

        txtMsg = findViewById(R.id.txtErr);
        txtMsg.setVisibility(View.INVISIBLE);

        TextView sigla_perfil = findViewById(R.id.sigla_perfil);
        sigla_perfil.setText(user.getSiglaNome());
        sigla_perfil.setOnClickListener(v -> {
            returnPerfil();
        });

        EditText edtNameUser = findViewById(R.id.edtNameUser);
        EditTextM edtEmail = findViewById(R.id.edtEmail);
        EditTextM edtSenha = findViewById(R.id.edtSenha);
        edtNameUser.setText(user.getNome());
        edtEmail.setText(user.getEmail());

        edtSenha.enablePass(this);
        edtSenha.setHint("Senha deve ter no minimo 6 carateres");
        edtEmail.enableEmail(database);

        // Alert customizado
        LayoutInflater inflater = LayoutInflater.from(this);
        View customView = inflater.inflate(R.layout.dialog_custom_layout, null);
        //AlertDialog alertDialog = new AlertDialog.Builder(this, R.style.MyAlertDialogStyle)
        AlertDialog alertDialog = new AlertDialog.Builder(this, R.style.MyAlertDialogStyle)
                .setView(customView)
                    .create();

        Button btnSalvarAlteracoes = findViewById(R.id.btnSalvarAlteracoes);
        btnSalvarAlteracoes.setOnClickListener(v -> {
            if (edtValid(edtNameUser) && edtValid(edtEmail) && edtValid(edtSenha))
                if (edtEmail.validateEmail(database, sessionManager) && edtSenha.validatePass(EditTextM.VALIDATE_CADASTRO)) {
                    String strNameUser = getEdtStr(edtNameUser);
                    String strEmail = getEdtStr(edtEmail);
                    String strSenha = getEdtStr(edtSenha);

                    UserModel userSave = new UserModel(user.getID(), strEmail, strNameUser, strSenha);
                    Long ID_or_Row = database.Model().getUser().insertOrUpdate(userSave);

                    txtMsg.setVisibility(View.VISIBLE);
                    txtMsg.setTextColor(Color.parseColor("#B1ED0E0E"));
                    txtMsg.setText("Alterações não foram feitas, algo deu errado.");

                    if (ID_or_Row > 0) {
                        userSave = database.Model().getUser().getUserByID(user.getID());
                        if (userSave != null) {
                            user = userSave;
                            sessionManager.saveUser(userSave);
                            sigla_perfil.setText(userSave.getSiglaNome());

                            txtMsg.setTextColor(Color.parseColor("#B1398913"));
                            txtMsg.setText("Alterações Feitas");
                        }
                    }
                }
        });
        ((Button) findViewById(R.id.btnCancelar)).setOnClickListener(v -> {
            returnPerfil();
        });
        ((Button) findViewById(R.id.btnExcluirConta)).setOnClickListener(v -> {
            alertDialog.show();

            ((Button) customView.findViewById(R.id.btn_cancelar)).setOnClickListener(v_btn_cancelar -> {
                alertDialog.dismiss();
            });

            ((Button) customView.findViewById(R.id.btn_confirmar)).setOnClickListener(v_btn_confirmar -> {
                alertDialog.dismiss();
                if (database.Model().getUser().deletar(user)>0)
                    sessionManager.limparSessao_e_logout();
            });
        });

        menuInferior.make(MenuHelp.DisablePerfil);
        menuInferior.markMenuIcon(MenuHelp.IC_PERFIL_EDITAR);
    }

    private void returnPerfil() {
        Intent intent = new Intent(this, PerfilActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    private boolean edtValid(@NonNull EditText ed) {
        if (ed.getText().toString().isBlank()) {
            txtMsg.setText("Há campos vazios!");
            txtMsg.setTextColor(Color.parseColor("#B1ED0E0E"));
            txtMsg.setVisibility(View.VISIBLE);
            return false;
        }
        return true;
    }

    private String getEdtStr(@NonNull EditText ed) {
        return ed.getText().toString();
    }
}