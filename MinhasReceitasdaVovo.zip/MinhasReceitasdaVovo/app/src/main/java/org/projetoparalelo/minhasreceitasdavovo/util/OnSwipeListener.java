package org.projetoparalelo.minhasreceitasdavovo.util;

public interface OnSwipeListener {
    void onSwipeRight();
    void onSwipeLeft();
}
