package org.projetoparalelo.minhasreceitasdavovo.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import org.projetoparalelo.minhasreceitasdavovo.db.model.DatabaseModel;
import org.projetoparalelo.minhasreceitasdavovo.db.model.UserModel;

public class DatabaseHelpe extends SQLiteOpenHelper {

    private static final String nome_banco = "minhas_receitas_da_vovo.db";
    private static final int version = 1;
    private final DatabaseModel dbModel;

    public DatabaseHelpe(@Nullable Context context) {
        super(context, nome_banco, null, version);
        dbModel = new DatabaseModel(this);
    }

    public DatabaseHelpe(@Nullable Context context, UserModel user) {
        super(context, nome_banco, null, version);
        dbModel = new DatabaseModel(context, this, user);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        dbModel.getUser(db).createTable();
        dbModel.getCategorias(db).createTable();
        dbModel.getIngredientes(db).createTable();
        dbModel.getReceitas(db).createTable();
        dbModel.getReceitasIngredientes(db).createTable();
        dbModel.getFavoritos(db).createTable();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        dbModel.getUser(db).dropTable();
        dbModel.getCategorias(db).dropTable();
        dbModel.getIngredientes(db).dropTable();
        dbModel.getReceitas(db).dropTable();
        dbModel.getReceitasIngredientes(db).dropTable();
        dbModel.getFavoritos(db).dropTable();

        onCreate(db);
    }

    public DatabaseModel Model() {
        return dbModel;
    }

    public void carregar() {
        dbModel.getCategorias().insert("Sobremesa");
        dbModel.getCategorias().insert("Prato Principal");
        dbModel.getCategorias().insert("Entrada");
        dbModel.getCategorias().insert("Café da Manhã");
        dbModel.getCategorias().insert("Lanche");

        String tipo = "Vegetais e Legumes";
        dbModel.getIngredientes().insert("Tomate", tipo);
        dbModel.getIngredientes().insert("Cebola", tipo);
        dbModel.getIngredientes().insert("Alho", tipo);
        dbModel.getIngredientes().insert("Cenoura", tipo);
        dbModel.getIngredientes().insert("Batata", tipo);
        dbModel.getIngredientes().insert("Abobrinha", tipo);
        dbModel.getIngredientes().insert("Pimentão vermelho", tipo);
        dbModel.getIngredientes().insert("Espinafre", tipo);
        dbModel.getIngredientes().insert("Couve-flor", tipo);
        dbModel.getIngredientes().insert("Brócolis", tipo);

        tipo = "Carnes e Proteínas";
        dbModel.getIngredientes().insert("Frango desfiado", tipo);
        dbModel.getIngredientes().insert("Carne moída", tipo);
        dbModel.getIngredientes().insert("Peito de frango", tipo);
        dbModel.getIngredientes().insert("Filé de peixe", tipo);
        dbModel.getIngredientes().insert("Linguiça calabresa", tipo);
        dbModel.getIngredientes().insert("Presunto", tipo);
        dbModel.getIngredientes().insert("Bacon", tipo);
        dbModel.getIngredientes().insert("Ovo", tipo);
        dbModel.getIngredientes().insert("Atum", tipo);
        dbModel.getIngredientes().insert("Tofu", tipo);

        tipo = "Grãos e Massas";
        dbModel.getIngredientes().insert("Arroz branco", tipo);
        dbModel.getIngredientes().insert("Arroz integral", tipo);
        dbModel.getIngredientes().insert("Macarrão penne", tipo);
        dbModel.getIngredientes().insert("Farinha de trigo", tipo);
        dbModel.getIngredientes().insert("Aveia", tipo);
        dbModel.getIngredientes().insert("Milho", tipo);
        dbModel.getIngredientes().insert("Feijão preto", tipo);
        dbModel.getIngredientes().insert("Lentilha", tipo);
        dbModel.getIngredientes().insert("Pão de forma", tipo);
        dbModel.getIngredientes().insert("Tapioca", tipo);

        tipo = "Temperos e Condimentos";
        dbModel.getIngredientes().insert("Sal", tipo);
        dbModel.getIngredientes().insert("Pimenta-do-reino", tipo);
        dbModel.getIngredientes().insert("Orégano", tipo);
        dbModel.getIngredientes().insert("Açafrão", tipo);
        dbModel.getIngredientes().insert("Páprica", tipo);
        dbModel.getIngredientes().insert("Curry", tipo);
        dbModel.getIngredientes().insert("Coentro", tipo);
        dbModel.getIngredientes().insert("Cominho", tipo);
        dbModel.getIngredientes().insert("Louro", tipo);

        tipo = "Doces e Outros";
        dbModel.getIngredientes().insert("Açúcar", tipo);
        dbModel.getIngredientes().insert("Chocolate em pó", tipo);
        dbModel.getIngredientes().insert("Leite condensado", tipo);
        dbModel.getIngredientes().insert("Creme de leite", tipo);
        dbModel.getIngredientes().insert("Fermento em pó", tipo);
        dbModel.getIngredientes().insert("Leite", tipo);
        dbModel.getIngredientes().insert("Manteiga", tipo);
        dbModel.getIngredientes().insert("Mel", tipo);
        dbModel.getIngredientes().insert("Baunilha", tipo);
        dbModel.getIngredientes().insert("Coco ralado", tipo);
    }
}
