package org.projetoparalelo.minhasreceitasdavovo.db.model;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.jetbrains.annotations.NotNull;
import org.projetoparalelo.minhasreceitasdavovo.db.CursoX;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class Model extends CursoX {

    private final String CreateTable;
    private SQLiteDatabase db;
    private static String Tabela;

    public Model(@NotNull String CreateTable, SQLiteDatabase db) {

        Pattern pattern = Pattern.compile("CREATE TABLE\\s+(\\w+)", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(CreateTable);
        if (matcher.find())
            Tabela = matcher.group(1);
        this.CreateTable = CreateTable;
        this.db = db;

        if (Tabela == null) throw new NullPointerException("O nome da tabela esta vazia");
    }

    public Model() { CreateTable=null; }

    public void createTable() {
        if (CreateTable == null) return;
        db.execSQL(CreateTable);
    }

    public void dropTable() {
        if (CreateTable == null) return;
        db.execSQL("DROP TABLE IF EXISTS "+Tabela);
    }

    public void close() {
        if (db == null) return;
        db.close();
    }

}
